<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - Chemical Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Chemical Trends</div>
  <ul class="nav-links">
    <li><a href="chem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Trending in 2025</span>
    <h1>Current Innovations in Chemical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>Modern Trends & Innovations</h2>
  <div class="branch-grid">

    <div class="branch-card chem">
      <h3>🌿 Green Chemistry</h3>
      <p>Designing processes that reduce or eliminate hazardous substances in production — driving sustainable innovation.</p>
    </div>

    <div class="branch-card cse">
      <h3>🧬 Nanotechnology</h3>
      <p>Creating nano-catalysts and materials with high surface area to improve reaction rates and energy efficiency.</p>
    </div>

    <div class="branch-card cseds">
      <h3>⚙️ Advanced Process Control</h3>
      <p>Using AI & ML to monitor, predict, and optimize chemical plant performance and reduce energy waste.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🌡️ Smart Sensors & IoT</h3>
      <p>IoT-enabled chemical plants allow real-time monitoring of temperature, pressure, and emissions.</p>
    </div>

    <div class="branch-card bio">
      <h3>🧪 Biochemical Engineering</h3>
      <p>Using microbes and enzymes to replace traditional processes, especially in pharma and green fuel sectors.</p>
    </div>

    <div class="branch-card mech">
      <h3>⚡ Hydrogen-Based Fuel Systems</h3>
      <p>Focus on chemical reactions that produce and store hydrogen safely for clean energy applications.</p>
    </div>

  </div>
</section>

</body>
</html>

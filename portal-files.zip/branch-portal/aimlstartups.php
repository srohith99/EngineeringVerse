<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - AIML</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">AIML Startups</div>
  <ul class="nav-links">
    <li><a href="aiml.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 Startup Power</span>
    <h1>Innovative AI/ML Startup Ideas</h1>
  </div>
</section>

<section class="branches">
  <h2>Ideas to Build & Scale</h2>
  <div class="branch-grid">

    <div class="branch-card aiml">
      <h3>👩‍🏫 AI Tutors & Personalized Learning</h3>
      <p>Build intelligent tutors that adapt to each student's learning pace and style using NLP + analytics.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🔍 Medical Image Diagnosis</h3>
      <p>AI-based diagnostics using X-rays, MRIs, and CT scans — especially for rural clinics and early detection.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>🎙️ Voice & Emotion AI</h3>
      <p>Create AI companions or call center automation using sentiment detection and speech-to-text models.</p>
    </div>

    <div class="branch-card mech">
      <h3>📈 ML for Agriculture</h3>
      <p>Predict crop yield, automate irrigation, and detect diseases using drones, sensors, and image classification.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🔐 AI for Cybersecurity</h3>
      <p>Smart intrusion detection systems, phishing prevention tools, and risk analytics powered by ML.</p>
    </div>

  </div>
</section>

</body>
</html>

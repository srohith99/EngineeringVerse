<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - EEE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">📚 EEE History</div>
  <ul class="nav-links">
    <li><a href="eee.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>📚 Powering Through Time</span>
    <h1>Milestones in Electrical & Electronics</h1>
  </div>
</section>

<section class="branches">
  <h2>Historic Innovations</h2>
  <div class="branch-grid">

    <div class="branch-card eee">
      <h3>🔌 Invention of Electricity</h3>
      <p>From Benjamin Franklin to Nikola Tesla and Edison — their discoveries led to the era of electrification and invention of AC/DC systems.</p>
    </div>

    <div class="branch-card chem">
      <h3>🔋 Development of Batteries</h3>
      <p>From the Voltaic pile to modern Li-ion cells, batteries became the heart of all mobile and remote systems.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>🖥️ Rise of Microcontrollers</h3>
      <p>Intel's 8051, PIC, and AVR opened the world to embedded control systems — powering everything from elevators to satellites.</p>
    </div>

    <div class="branch-card mech">
      <h3>🎛️ SCADA & PLC Evolution</h3>
      <p>Revolutionized factory automation and remote control of critical infrastructure like dams, grids, and plants.</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - IEM</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">🔮 IEM Future</div>
  <ul class="nav-links">
    <li><a href="iem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🔮 Reimagining Operations</span>
    <h1>Future Scope in IEM</h1>
  </div>
</section>

<section class="branches">
  <h2>Where the Industry is Heading</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>🌐 Digital Twins</h3>
      <p>Virtual clones of physical factories will allow real-time simulation, diagnosis, and optimization of production systems.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🧠 AI-Driven Decision Engines</h3>
      <p>Managers will rely on intelligent platforms that suggest strategic decisions based on big data patterns and forecasting.</p>
    </div>

    <div class="branch-card csbs">
      <h3>💡 Autonomous Planning Systems</h3>
      <p>ERP systems will evolve to independently plan resources, optimize scheduling, and manage supply-demand dynamically.</p>
    </div>

    <div class="branch-card chem">
      <h3>🦾 Human-Robot Collaboration</h3>
      <p>Collaborative robots (cobots) will safely assist humans on factory floors, increasing efficiency and safety.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>📈 Predictive Maintenance</h3>
      <p>IoT sensors and ML will predict equipment failures before they happen, reducing downtime and costs.</p>
    </div>

  </div>
</section>

</body>
</html>

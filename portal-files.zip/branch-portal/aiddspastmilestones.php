<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - AIDD</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">AIDD History</div>
  <ul class="nav-links">
    <li><a href="aidd.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>How We Got Here</span>
    <h1>Milestones in AI & Data Science</h1>
  </div>
</section>

<section class="branches">
  <h2>Important Events</h2>
  <div class="branch-grid">

    <div class="branch-card aidd">
      <h3>📊 Hadoop Revolution (2005)</h3>
      <p>MapReduce and Hadoop allowed storing & processing petabytes of data — the rise of Big Data.</p>
    </div>

    <div class="

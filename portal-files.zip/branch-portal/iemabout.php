<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About - IEM</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">📘 About IEM</div>
  <ul class="nav-links">
    <li><a href="iem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🏭 The Smart Link Between Industry & Management</span>
    <h1>What is Industrial Engineering & Management?</h1>
  </div>
</section>

<section class="branches">
  <h2>Overview</h2>
  <div class="branch-grid">
    <div class="branch-card iem">
      <p>IEM is a multidisciplinary branch that merges engineering principles with business intelligence. It focuses on optimizing complex processes, improving productivity, and minimizing waste in manufacturing, logistics, and service industries.</p>
      <p>From process modeling to strategic planning, IEM professionals are trained in analytics, operations research, automation, human factors, and supply chain management.</p>
    </div>
  </div>
</section>

</body>
</html>

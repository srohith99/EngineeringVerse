<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - ECE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <nav class="navbar">
    <div class="logo">ECE Startups</div>
    <ul class="nav-links">
      <li><a href="ece.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <section class="branches">
    <h2>Startup Ideas for ECE Students</h2>
    <div class="branch-grid">

      <div class="branch-card mech">
        <h3>🏠 Smart Home Automation</h3>
        <p>Design IoT-enabled lights, fans, and sensors with mobile app control.</p>
      </div>

      <div class="branch-card aiml">
        <h3>🔐 IoT Security Systems</h3>
        <p>Develop encrypted embedded systems for surveillance and alerts.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🧠 FPGA-based AI Devices</h3>
        <p>Real-time gesture & speech recognition using edge-AI on FPGAs.</p>
      </div>

      <div class="branch-card csbs">
        <h3>📶 Antenna Tech Startups</h3>
        <p>Miniature, foldable antennas for wearables and biomedical devices.</p>
      </div>

    </div>
  </section>

</body>
</html>

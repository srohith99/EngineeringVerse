<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - CSBS</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Milestones – CSBS</div>
  <ul class="nav-links">
    <li><a href="csbs.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Legacy Moments</span>
    <h1>CSBS Milestones</h1>
    <p>From spreadsheets to AI-powered business software — the story of enterprise transformation.</p>
  </div>
</section>

<section class="branches">
  <h2>Key Breakthroughs</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>1980s – MIS Systems</h3>
      <p>Business started adopting Management Information Systems for better decision support.</p>
    </div>

    <div class="branch-card bio">
      <h3>1990s – Enterprise Resource Planning</h3>
      <p>Software like SAP revolutionized how firms handled HR, inventory, finance and CRM.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>2000s – Business Intelligence Tools</h3>
      <p>Data warehousing and reporting tools (e.g. SAS, Oracle BI) changed how analytics worked.</p>
    </div>

    <div class="branch-card eee">
      <h3>2010s – Cloud & Automation</h3>
      <p>SaaS ERPs, cloud CRMs, and automation platforms changed traditional business IT forever.</p>
    </div>

  </div>
</section>

</body>
</html>

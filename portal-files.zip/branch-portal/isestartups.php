<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - ISE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">ISE Startups</div>
  <ul class="nav-links">
    <li><a href="ise.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 Innovation Meets Information</span>
    <h1>Startup Ideas in Information Science</h1>
  </div>
</section>

<section class="branches">
  <h2>Ideas for Building the Future</h2>
  <div class="branch-grid">

    <div class="branch-card cseds">
      <h3>🔍 Smart Research Assistant</h3>
      <p>An AI-powered web tool that helps students & researchers summarize, analyze, and cite academic content in real-time. (Tech: LLMs + NLP + Firebase)</p>
    </div>

    <div class="branch-card chem">
      <h3>🧠 Personal Knowledge Manager</h3>
      <p>A private, encrypted graph-based app where users store notes, tags, links and see auto-generated connections. (Tech: Neo4j, React, Electron)</p>
    </div>

    <div class="branch-card aidd">
      <h3>📊 Visual Data Insight Generator</h3>
      <p>A no-code tool that converts raw CSV/Excel data into interactive dashboards using ML. (Tech: Python, Streamlit, Plotly, Pandas)</p>
    </div>

    <div class="branch-card mech">
      <h3>🔐 AI-Driven Privacy Scanner</h3>
      <p>Startup for privacy auditing of websites/apps using AI to detect tracking & vulnerabilities. (Tech: Puppeteer, Node.js, OWASP)</p>
    </div>

    <div class="branch-card cse">
      <h3>📁 Cloud-based File Recommender</h3>
      <p>Google Drive-style platform that predicts and suggests documents based on task, time, and habit. (Tech: TensorFlow, Firebase, Next.js)</p>
    </div>

    <div class="branch-card bio">
      <h3>🧬 Health Info Tracker with NLP</h3>
      <p>Extract medical terms and doctor recommendations from prescriptions, lab reports, and convert into digital structured insights. (Tech: OCR, NLP, MongoDB)</p>
    </div>

  </div>
</section>

</body>
</html>

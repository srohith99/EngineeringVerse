<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - Biotechnology</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Biotech Future</div>
  <ul class="nav-links">
    <li><a href="bio.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Looking Ahead</span>
    <h1>Future Scope of Biotechnology</h1>
  </div>
</section>

<section class="branches">
  <h2>Where Biotechnology is Headed</h2>
  <div class="branch-grid">

    <div class="branch-card bio">
      <h3>🧠 Bio-AI Integration</h3>
      <p>AI will accelerate biotech breakthroughs — from predicting protein structures to optimizing drug discovery cycles.</p>
    </div>

    <div class="branch-card chem">
      <h3>🫀 Organ Bioprinting</h3>
      <p>Using 3D bioprinters to create organs like kidneys and livers using patient’s own cells — reducing transplant dependencies.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>🌾 Precision Agriculture</h3>
      <p>Combining genomics and IoT to enhance food quality, yield, and resilience against climate change.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🧬 DNA Data Storage</h3>
      <p>Encoding digital data in DNA — allowing immense storage in microscopic space, resistant to time and degradation.</p>
    </div>

    <div class="branch-card aidd">
      <h3>💉 Personalized Therapeutics</h3>
      <p>Gene and cell therapies tailored to each individual based on genomic sequencing for unmatched effectiveness.</p>
    </div>

    <div class="branch-card mech">
      <h3>♻️ Industrial Biotech & Green Tech</h3>
      <p>Eco-friendly plastics, enzyme-based waste recycling, and sustainable biofuels will reduce environmental impact drastically.</p>
    </div>

  </div>
</section>

</body>
</html>

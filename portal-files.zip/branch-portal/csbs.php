<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSBS - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">CSBS Branch</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>👋 Welcome to</span>
    <h1>Computer Science & Business Systems (CSBS)</h1>
    <p>A fusion of technology and business intelligence built for modern enterprise ecosystems.</p>
  </div>
</section>

<!-- CONTENT GRID -->
<section class="branches">
  <h2>Explore CSBS Dimensions</h2>
  <div class="branch-grid">

    <div class="branch-card csbs">
      <h3><a href="csbsabout.php">📘 About CSBS</a></h3>
      <p>Understand what makes CSBS different — industry relevance, business integration, and more.</p>
    </div>

    <div class="branch-card aiml">
      <h3><a href="csbscurrenttrends.php">🔥 Current Trends</a></h3>
      <p>Enterprise AI, FinTech platforms, data governance, ERP analytics — all driving business transformation.</p>
    </div>

    <div class="branch-card cseiot">
      <h3><a href="csbsfuturescope.php">🚀 Future Scope</a></h3>
      <p>Rise of AI-led decisions, data-driven leadership, and tech-enabled business strategy roles.</p>
    </div>

    <div class="branch-card eee">
      <h3><a href="csbspastmilestones.php">📚 Past Milestones</a></h3>
      <p>Evolution from MIS to AI-driven CRM, automation tools, and integrated enterprise platforms.</p>
    </div>

    <div class="branch-card bio">
      <h3><a href="csbsstartups.php">💡 Startup Ideas</a></h3>
      <p>Ideas blending tech + business like analytics dashboards, HR tech, SaaS CRMs, and financial automation.</p>
    </div>

  </div>
</section>

</body>
</html>

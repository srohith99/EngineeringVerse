<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - ECE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <nav class="navbar">
    <div class="logo">Future Scope - ECE</div>
    <ul class="nav-links">
      <li><a href="ece.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <section class="branches">
    <h2>Future Scope in ECE</h2>
    <div class="branch-grid">

      <div class="branch-card aiml">
        <h3>🔬 Neuromorphic & AI Chips</h3>
        <p>Chips that mimic human brain functionality — the future of AI acceleration.</p>
      </div>

      <div class="branch-card chem">
        <h3>🚀 Space Communication</h3>
        <p>Low-earth orbit satellites and interstellar communication research rising fast.</p>
      </div>

      <div class="branch-card eee">
        <h3>🌐 Internet of Everything (IoE)</h3>
        <p>Everything — not just devices — will be connected and data-driven.</p>
      </div>

      <div class="branch-card mech">
        <h3>🎛️ Smart Robotics</h3>
        <p>Autonomous bots with real-time sensing, edge ML, and seamless communication.</p>
      </div>

    </div>
  </section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - IEM</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">⚙️ IEM Trends</div>
  <ul class="nav-links">
    <li><a href="iem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 Where Industry Meets Intelligence</span>
    <h1>Current Trends in IEM</h1>
  </div>
</section>

<section class="branches">
  <h2>Technologies & Practices in 2025</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>🏭 Industry 4.0</h3>
      <p>Integration of cyber-physical systems, IoT, and data analytics for intelligent manufacturing systems.</p>
    </div>

    <div class="branch-card aiml">
      <h3>📊 Data-Driven Decision Making</h3>
      <p>Using predictive analytics and dashboards to optimize production, inventory, and logistics in real time.</p>
    </div>

    <div class="branch-card chem">
      <h3>🔄 Lean Six Sigma</h3>
      <p>Continual focus on process improvement, quality control, and efficiency with lean methodologies.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>📦 Smart Supply Chains</h3>
      <p>Real-time tracking, autonomous transport, and blockchain traceability in complex logistics networks.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🤖 Robotic Process Automation (RPA)</h3>
      <p>Automating repetitive business tasks with bots to reduce human error and operational time.</p>
    </div>

  </div>
</section>

</body>
</html>

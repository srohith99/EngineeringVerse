<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Engineering Trends Portal</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVIGATION -->
  <nav class="navbar">
    <div class="logo">⚙️ Engg Trends</div>
    <ul class="nav-links">
      <li><a href="index.php">Home</a></li>
      <li><a href="branches.php">Branches</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <!-- HERO SECTION -->
  <section class="hero-section">
  <div class="hero-glass">
    <span><p>👋 Welcome,</p> <?php echo $_SESSION['user']; ?>!</span>
    <p><strong>Explore latest trends, innovations, and future scope across all engineering branches.<strong></p>
  </div>
</section>


  <!-- BRANCH SELECTION GRID -->
  <section class="branches">
    <h2>Select Your Branch</h2>
    <div class="branch-grid">

      <a href="civil.php" class="branch-card civil">Civil Engineering</a>
      <a href="mech.php" class="branch-card mech">Mechanical Engineering</a>
      <a href="eee.php" class="branch-card eee">Electrical & Electronics Engg</a>
      <a href="ece.php" class="branch-card ece">Electronics & Communication Engg</a>
      <a href="iem.php" class="branch-card iem">Industrial Engg & Management</a>
      <a href="cse.php" class="branch-card cse">Computer Science & Engineering</a>
      <a href="ise.php" class="branch-card ise">Information Science & Engineering</a>
      <a href="bio.php" class="branch-card bio">Biotechnology</a>
      <a href="chem.php" class="branch-card chem">Chemical Engineering</a>
      <a href="aiml.php" class="branch-card aiml">AI & Machine Learning</a>
      <a href="aidds.php" class="branch-card aidd">AI & Data Science</a>
      <a href="cseds.php" class="branch-card cseds">CSE - Data Science</a>
      <a href="cseiot.php" class="branch-card cseiot">CSE - IoT, Cybersecurity & Blockchain</a>
      <a href="csbs.php" class="branch-card csbs">CS & Business Systems</a>

    </div>
  </section>

</body>
</html>

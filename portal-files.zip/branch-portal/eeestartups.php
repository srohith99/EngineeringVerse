<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startups - EEE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">💡 EEE Startups</div>
  <ul class="nav-links">
    <li><a href="eee.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>💡 Powering Innovation</span>
    <h1>Startup Ideas in Electrical & Electronics</h1>
  </div>
</section>

<section class="branches">
  <h2>Real-World Business Possibilities</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>🔋 EV Conversion Kits</h3>
      <p>Provide electric conversion services for petrol two-wheelers and auto-rickshaws, powered by brushless DC motors and battery packs.</p>
    </div>

    <div class="branch-card csbs">
      <h3>🔌 Smart Home Automation</h3>
      <p>Design plug-and-play kits that control lights, fans, and appliances using mobile apps and voice assistants like Alexa.</p>
    </div>

    <div class="branch-card bio">
      <h3>🌞 Solar Rooftop Installers</h3>
      <p>Start a certified EPC company that installs residential solar panels integrated with net metering and real-time monitoring.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>📶 Industrial IoT Analytics</h3>
      <p>Build platforms that monitor machine health, energy usage, and automate predictive maintenance using sensors and cloud dashboards.</p>
    </div>

  </div>
</section>

</body>
</html>

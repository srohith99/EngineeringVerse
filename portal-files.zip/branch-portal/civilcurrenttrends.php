<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - Civil Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">🌐 Civil Trends</div>
    <ul class="nav-links">
      <li><a href="civil.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HERO SECTION -->
  <section class="hero-section">
    <div class="hero-glass">
      <span>🔍 Explore Current Innovations</span>
      <h1>Latest Trends in Civil Engineering (2025)</h1>
    </div>
  </section>

  <!-- TRENDS SECTION -->
  <section class="branches">
    <h2>Technologies Shaping the Future</h2>
    <div class="branch-grid">

      <div class="branch-card chem">
        <h3>🏙️ Building Information Modeling (BIM)</h3>
        <p>BIM allows 3D modeling and real-time collaboration for designing infrastructure — enhancing accuracy and project efficiency.</p>
      </div>

      <div class="branch-card mech">
        <h3>🏗️ 3D Concrete Printing</h3>
        <p>Revolutionizing construction speed and cost, 3D printing enables rapid, eco-friendly housing and structural prototypes.</p>
      </div>

      <div class="branch-card ece">
        <h3>🌱 Sustainable Materials</h3>
        <p>Use of bamboo, self-healing concrete, recycled plastic bricks, and carbon-neutral cement is on the rise in green construction.</p>
      </div>

      <div class="branch-card cseds">
        <h3>🌐 Smart City Infrastructure</h3>
        <p>IoT sensors, smart traffic lights, and energy-efficient systems are transforming cities into responsive and sustainable environments.</p>
      </div>

      <div class="branch-card aidd">
        <h3>🛰️ Drones & Aerial Surveying</h3>
        <p>Drones assist in surveying, mapping, and monitoring construction sites with precision and safety.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>📡 AI & Data Analytics</h3>
        <p>Machine learning is used in predicting structural failures, optimizing designs, and managing mega-projects efficiently.</p>
      </div>

    </div>
  </section>

</body>
</html>

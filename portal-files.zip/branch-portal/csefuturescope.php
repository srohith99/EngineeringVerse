<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - CSE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">Future Scope</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="cse.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HEADER -->
  <section class="hero-section">
    <h1>Future Scope in Computer Science</h1>
    <div class="hero-glass">
      <span>🌟 Hello, <?php echo $_SESSION['user']; ?>!</span>
      <p>Explore where CSE can take you in the next 5–10 years – careers, trends & innovations!</p>
    </div>
  </section>

  <!-- FUTURE SCOPE SECTION -->
  <section class="branches">
    <h2>Where is CSE Heading?</h2>
    <div class="branch-grid">

      <div class="branch-card aiml">
        <h3>🤖 AI & Automation Architect</h3>
        <p>Future engineers will develop AI models, decision engines, and ethical algorithms for businesses.</p>
      </div>

      <div class="branch-card cseds">
        <h3>🧠 Research in Quantum Computing</h3>
        <p>Quantum computers will reshape how we solve complex problems in cryptography and physics.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🌐 Full-Stack Web3 Developer</h3>
        <p>Decentralized apps (DApps), crypto wallets, and smart contracts will be in huge demand.</p>
      </div>

      <div class="branch-card aidd">
        <h3>📈 Data Scientist & AI Analyst</h3>
        <p>With every industry becoming data-driven, AI-based analysis and automation will dominate careers.</p>
      </div>

      <div class="branch-card chem">
        <h3>🔐 Cybersecurity Architect</h3>
        <p>Governments and industries will demand experts to secure national infrastructure and digital trust.</p>
      </div>

      <div class="branch-card csbs">
        <h3>🚀 CTO / Tech Product Founder</h3>
        <p>CSE students are increasingly launching startups in edtech, fintech, AI, gaming, and more.</p>
      </div>

    </div>
  </section>

</body>
</html>

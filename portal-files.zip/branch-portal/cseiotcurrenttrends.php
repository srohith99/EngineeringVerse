<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - CSE (IoT, Cyber & Blockchain)</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">Current Trends – CSE-IoT</div>
  <ul class="nav-links">
    <li><a href="cseiot.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>What's Buzzing in 2025?</span>
    <h1>Emerging Trends in IoT, Cybersecurity & Blockchain</h1>
    <p>Stay ahead with technologies shaping secure, smart, and decentralized ecosystems.</p>
  </div>
</section>

<!-- TREND GRID -->
<section class="branches">
  <h2>Top 2025 Trends</h2>
  <div class="branch-grid">

    <div class="branch-card cseiot">
      <h3>🔐 Zero Trust Architecture (ZTA)</h3>
      <p>Every access request is verified regardless of network origin. No implicit trust = high security.</p>
    </div>

    <div class="branch-card csbs">
      <h3>🌐 Blockchain-as-a-Service (BaaS)</h3>
      <p>Cloud-based platforms offering easy blockchain integration for enterprises and apps.</p>
    </div>

    <div class="branch-card chem">
      <h3>🧠 AI-Powered Threat Detection</h3>
      <p>ML models monitor and respond to cyber threats in real-time using behavioral analytics.</p>
    </div>

    <div class="branch-card bio">
      <h3>📡 Massive IoT Deployments</h3>
      <p>Smart cities, connected cars, wearable health devices — all linked via 5G/6G.</p>
    </div>

    <div class="branch-card aidd">
      <h3>⚙️ Decentralized Identity (DID)</h3>
      <p>Self-sovereign ID systems using blockchain to secure personal credentials and reduce fraud.</p>
    </div>

    <div class="branch-card ece">
      <h3>⛓️ Layer 2 Blockchain Scaling</h3>
      <p>Optimizing Ethereum & Bitcoin with Lightning, Optimism, and zk-Rollups for mass adoption.</p>
    </div>

    <div class="branch-card mech">
      <h3>📶 6G-Enabled IoT</h3>
      <p>Ultra-low-latency networks boosting real-time IoT response, especially for robotics and vehicles.</p>
    </div>

    <div class="branch-card eee">
      <h3>🎯 Hardware-level Security</h3>
      <p>TPM, Secure Enclave, hardware firewalls in embedded and IoT devices for root-level defense.</p>
    </div>

  </div>
</section>

</body>
</html>

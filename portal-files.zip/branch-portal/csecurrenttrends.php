<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - CSE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">CSE Trends</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="cse.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HEADER & WELCOME -->
  <section class="hero-section">
    <h1>Current Trends in Computer Science</h1>
    <div class="hero-glass">
      <span>👋 Hello, <?php echo $_SESSION['user']; ?>!</span>
      <p>Explore the top evolving technologies that are driving the CSE industry forward in 2025 and beyond.</p>
    </div>
  </section>

  <!-- TRENDING TOPICS GRID -->
  <section class="branches">
    <h2>Trending Technologies in 2025</h2>
    <div class="branch-grid">

      <div class="branch-card aiml">
        <h3>🤖 AI & Machine Learning</h3>
        <p>Driving automation, intelligent decision-making, and personalization across sectors.</p>
      </div>

      <div class="branch-card cseds">
        <h3>☁️ Cloud Computing</h3>
        <p>Empowering scalable applications with platforms like AWS, Azure, and Google Cloud.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🔐 Cybersecurity & Ethical Hacking</h3>
        <p>Crucial for protecting sensitive systems and networks from ever-evolving threats.</p>
      </div>

      <div class="branch-card cse">
        <h3>💰 Blockchain & Web3</h3>
        <p>Enabling decentralized trust, transparency, and secure smart contracts globally.</p>
      </div>

      <div class="branch-card bio">
        <h3>📱 Mobile App Development</h3>
        <p>Cross-platform tools like Flutter & React Native drive modern digital experiences.</p>
      </div>

      <div class="branch-card aidd">
        <h3>🧠 Data Science & Big Data</h3>
        <p>Leveraging massive data sets to uncover insights using Python, Spark, and ML tools.</p>
      </div>

    </div>
  </section>

</body>
</html>

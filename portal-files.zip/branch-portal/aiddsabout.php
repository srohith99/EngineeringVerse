<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About AIDD</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">About AIDD</div>
  <ul class="nav-links">
    <li><a href="aidd.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Dive into</span>
    <h1>AI & Data Science</h1>
  </div>
</section>

<section class="branches">
  <h2>What is AIDD?</h2>
  <div class="branch-grid">

    <div class="branch-card aidd">
      <h3>📊 AI + Data</h3>
      <p>AI automates tasks and decisions. Data Science extracts insights. Together, they power intelligent systems across sectors.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🔧 Core Subjects</h3>
      <p>Statistics, Machine Learning, Deep Learning, NLP, Data Mining, Data Visualization, Cloud Computing, Big Data</p>
    </div>

    <div class="branch-card mech">
      <h3>💻 Tools & Platforms</h3>
      <p>Python, R, TensorFlow, Scikit-learn, Pandas, Hadoop, Spark, Jupyter, AWS, Tableau, PowerBI</p>
    </div>

    <div class="branch-card aiml">
      <h3>📈 Career Roles</h3>
      <p>Data Scientist, ML Engineer, Data Engineer, AI Researcher, BI Analyst, AI Product Manager</p>
    </div>

  </div>
</section>

</body>
</html>

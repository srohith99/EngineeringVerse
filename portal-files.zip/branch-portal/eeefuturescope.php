<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - EEE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">🔮 EEE Future</div>
  <ul class="nav-links">
    <li><a href="eee.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🔮 Glimpse into Tomorrow</span>
    <h1>Future Scope of Electrical & Electronics Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>Where the Field is Heading</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>⚡ Wireless Power Transmission</h3>
      <p>Charging devices without cables will become mainstream — from smartphones to EVs, enabled by high-frequency resonant inductive coupling.</p>
    </div>

    <div class="branch-card aiml">
      <h3>🧠 AI-Controlled Smart Grids</h3>
      <p>Machine learning will forecast demand, detect faults, and adjust load distribution automatically in next-gen power systems.</p>
    </div>

    <div class="branch-card bio">
      <h3>💡 Bio-Inspired Sensors</h3>
      <p>EEE will contribute to healthcare by developing flexible biosensors and implantable devices for real-time monitoring.</p>
    </div>

    <div class="branch-card chem">
      <h3>🔋 Quantum Battery Technology</h3>
      <p>Quantum-level energy storage promises faster charging, smaller sizes, and longer-lasting batteries.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🌍 Energy Internet</h3>
      <p>A decentralized web of producers and consumers where homes, vehicles, and industries become both generators and users of power.</p>
    </div>

  </div>
</section>

</body>
</html>

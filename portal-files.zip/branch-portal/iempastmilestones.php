<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - IEM</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">📚 IEM History</div>
  <ul class="nav-links">
    <li><a href="iem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🕰️ Milestones in Management and Engineering</span>
    <h1>Past Achievements in IEM</h1>
  </div>
</section>

<section class="branches">
  <h2>Historical Contributions</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>📐 Scientific Management (Taylorism)</h3>
      <p>Frederick Taylor revolutionized manufacturing with time-motion studies, setting the base for modern productivity science.</p>
    </div>

    <div class="branch-card bio">
      <h3>🏭 Assembly Line - Henry Ford</h3>
      <p>Mass production systems started with Ford’s moving assembly lines, minimizing production time drastically.</p>
    </div>

    <div class="branch-card chem">
      <h3>🔄 Total Quality Management (TQM)</h3>
      <p>TQM practices brought customer-centric quality control as a mainstream discipline in production industries.</p>
    </div>

    <div class="branch-card csbs">
      <h3>📦 ERP Systems</h3>
      <p>Enterprise Resource Planning platforms like SAP transformed resource management, supply chains, and finance coordination.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>🎯 Six Sigma & Lean Tools</h3>
      <p>DMAIC, 5S, and lean principles shaped defect-free, fast, and cost-effective manufacturing environments worldwide.</p>
    </div>

  </div>
</section>

</body>
</html>

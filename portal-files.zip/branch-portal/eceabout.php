<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About ECE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <nav class="navbar">
    <div class="logo">About ECE</div>
    <ul class="nav-links">
      <li><a href="ece.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <section class="hero-section">
    <div class="hero-glass">
      <h1>What is ECE?</h1>
      <p>Electronics and Communication Engineering (ECE) focuses on designing, developing, and maintaining communication and embedded electronic systems. It blends core electronics with signal processing, communication networks, and microelectronics.</p>
      <p>Students learn about circuits, VLSI, IoT systems, microcontrollers, wireless communication, and more — enabling them to innovate across multiple domains.</p>
    </div>
  </section>

</body>
</html>

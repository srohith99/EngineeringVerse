<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ISE - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">ISE Branch</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="iseabout.php">📚 About ISE</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Welcome to</span>
    <h1>Information Science & Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>What You'll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card ise">
      <h3><a href="isecurrenttrends.php">🔥 Current Trends</a></h3>
      <p>Big Data, Cloud Services, NLP, Knowledge Graphs, Cybersecurity, and more.</p>
    </div>

    <div class="branch-card cse">
      <h3><a href="isestartups.php">💡 Startup Ideas</a></h3>
      <p>Data-driven apps, Enterprise knowledge platforms, Security monitoring systems.</p>
    </div>

    <div class="branch-card cseds">
      <h3><a href="isefuturescope.php">📈 Future Scope</a></h3>
      <p>Explainable AI, Intelligent Knowledge Networks, Human-AI Collaboration.</p>
    </div>

    <div class="branch-card bio">
      <h3><a href="isepastmilestones.php">📚 Past Milestones</a></h3>
      <p>From File Systems to Cloud Storage, Database evolution, Internet boom.</p>
    </div>

  </div>
</section>

</body>
</html>

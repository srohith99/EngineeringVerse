<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About CSBS</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">About CSBS</div>
  <ul class="nav-links">
    <li><a href="csbs.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>What is CSBS?</span>
    <h1>Computer Science & Business Systems</h1>
    <p>A program designed by TCS & AICTE to blend core computer science with business acumen.</p>
  </div>
</section>

<section class="branches">
  <h2>Why CSBS Matters</h2>
  <div class="branch-grid">

    <div class="branch-card cse">
      <h3>💻 Computer Science Core</h3>
      <p>Includes DSA, OS, DBMS, Web Dev, AI, ML, Cloud, Cybersecurity, and more.</p>
    </div>

    <div class="branch-card csbs">
      <h3>📊 Business Fundamentals</h3>
      <p>Managerial economics, financial systems, business analytics, and strategy principles are part of the curriculum.</p>
    </div>

    <div class="branch-card bio">
      <h3>🔄 Industry Alignment</h3>
      <p>CSBS prepares students for enterprise-level thinking and cross-functional roles in IT and business domains.</p>
    </div>

  </div>
</section>

</body>
</html>

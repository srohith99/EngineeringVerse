<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Chemical Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">About Chemical Engg</div>
  <ul class="nav-links">
    <li><a href="chem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Deep Dive into</span>
    <h1>Chemical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>Overview of Chemical Engineering</h2>
  <div class="branch-grid">

    <div class="branch-card chem">
      <h3>⚗️ What is Chemical Engineering?</h3>
      <p>It deals with the design, optimization, and operation of processes that convert raw materials into valuable products using physical, chemical, or biological techniques.</p>
    </div>

    <div class="branch-card bio">
      <h3>🌍 Core Domains</h3>
      <p>Thermodynamics, Reaction Engineering, Fluid Mechanics, Process Control, Mass & Heat Transfer, Environmental Engineering</p>
    </div>

    <div class="branch-card cseds">
      <h3>🏭 Industries Involved</h3>
      <p>Chemicals, Petrochemicals, Pharmaceuticals, Food Processing, Polymers, Energy, Fertilizers, Biotech, Cosmetics</p>
    </div>

    <div class="branch-card mech">
      <h3>🧪 Impact</h3>
      <p>Chemical engineers play a crucial role in tackling climate change, developing cleaner fuels, sustainable packaging, and life-saving drugs.</p>
    </div>

  </div>
</section>

</body>
</html>

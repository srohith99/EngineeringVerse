<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - CSBS</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Future – CSBS</div>
  <ul class="nav-links">
    <li><a href="csbs.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Forecasting Ahead</span>
    <h1>Future Scope of CSBS</h1>
    <p>Tomorrow’s business leaders will be tech architects. Here's how CSBS leads the way.</p>
  </div>
</section>

<section class="branches">
  <h2>What's on the Horizon?</h2>
  <div class="branch-grid">

    <div class="branch-card cseds">
      <h3>🎯 Techno-Business Leaders</h3>
      <p>Future IT managers will need to understand both code and commerce for strategic decision making.</p>
    </div>

    <div class="branch-card chem">
      <h3>💼 Business AI Advisors</h3>
      <p>CSBS grads will fit into hybrid roles — deploying AI for operations, HR, logistics, and finance.</p>
    </div>

    <div class="branch-card aiml">
      <h3>🌐 Product Management + Data</h3>
      <p>Data-literate product managers and customer success leaders will drive next-gen tech firms.</p>
    </div>

  </div>
</section>

</body>
</html>

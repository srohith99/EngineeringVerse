<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About CSE (DS)</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">About CSDS</div>
  <ul class="nav-links">
    <li><a href="cseds.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Know Your Branch:</span>
    <h1>Computer Science & Engineering (Data Science)</h1>
  </div>
</section>

<section class="branches">
  <h2>Overview</h2>
  <div class="branch-grid">
    <div class="branch-card cseds">
      <p>This program blends computer science fundamentals with advanced data science techniques. Students learn AI/ML, data mining, visualization, and cloud computing, enabling them to build scalable, data-driven solutions.</p>
    </div>
  </div>
</section>

</body>
</html>

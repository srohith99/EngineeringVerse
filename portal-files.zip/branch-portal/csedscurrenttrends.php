<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSDS Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Current Trends</div>
  <ul class="nav-links">
    <li><a href="csds.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Trending in 2025:</span>
    <h1>Data Science</h1>
  </div>
</section>

<section class="branches">
  <h2>Top Tech Trends</h2>
  <div class="branch-grid">

    <div class="branch-card cseds">
      <h3>🧠 Explainable AI</h3>
      <p>Models that provide transparent, understandable decision-making paths.</p>
    </div>

    <div class="branch-card aiml">
      <h3>⚙️ DataOps</h3>
      <p>Automated data pipelines for faster, cleaner, and more efficient delivery.</p>
    </div>

    <div class="branch-card aidd">
      <h3>📈 Augmented Analytics</h3>
      <p>AI tools that empower non-tech users to gain insights from data easily.</p>
    </div>

    <div class="branch-card mech">
      <h3>📊 Real-Time Dashboards</h3>
      <p>Live analytics platforms showing trends instantly using tools like Grafana and Power BI.</p>
    </div>

  </div>
</section>

</body>
</html>

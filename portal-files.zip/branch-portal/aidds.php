<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AI & Data Science - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">AI & DS</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="aiddsabout.php">📚 About AIDD</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Welcome to</span>
    <h1>AI & Data Science</h1>
  </div>
</section>

<section class="branches">
  <h2>What You'll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card aidd">
      <h3><a href="aiddscurrenttrends.php">🔥 Current Trends</a></h3>
      <p>Generative AI, Big Data Engineering, AutoML, Responsible AI, Vector Databases</p>
    </div>

    <div class="branch-card aiml">
      <h3><a href="aiddsstartups.php">💡 Startup Ideas</a></h3>
      <p>AI analytics platforms, fraud detection systems, ML-based CRMs, data observability tools</p>
    </div>

    <div class="branch-card cseds">
      <h3><a href="aiddsfuturescope.php">📈 Future Scope</a></h3>
      <p>Data fabric, synthetic data generation, real-time analytics, LLMs for enterprise</p>
    </div>

    <div class="branch-card mech">
      <h3><a href="aiddspastmilestones.php">📚 Past Milestones</a></h3>
      <p>Rise of Big Data, Hadoop & Spark, Data Lake evolution, birth of deep analytics</p>
    </div>

  </div>
</section>

</body>
</html>

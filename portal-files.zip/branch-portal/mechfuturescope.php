<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - Mechanical</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">📈 Future Mech</div>
  <ul class="nav-links">
    <li><a href="mech.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🔮 Vision 2030+</span>
    <h1>Future Scope of Mechanical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>What's Ahead?</h2>
  <div class="branch-grid">

    <div class="branch-card bio">
      <h3>🏭 Fully Autonomous Factories</h3>
      <p>Robots and AI-powered systems will manage entire production cycles with minimal human supervision.</p>
    </div>

    <div class="branch-card mech">
      <h3>🧠 Human-Machine Interfaces</h3>
      <p>Mechanical engineers will design exoskeletons and assistive machines that respond to neural commands.</p>
    </div>

    <div class="branch-card eee">
      <h3>🚀 Aerospace Propulsion Systems</h3>
      <p>Advanced propulsion systems for space tourism and interplanetary travel will require precision mechanical expertise.</p>
    </div>

    <div class="branch-card chem">
      <h3>🌱 Sustainable Thermal Systems</h3>
      <p>Solar-powered HVACs and waste-heat-recovery turbines will dominate energy systems.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🧬 Nano-mechanical Devices</h3>
      <p>Micro-robots and nanotech mechanisms for drug delivery, pollution sensing, and atomic-level fabrication.</p>
    </div>

    <div class="branch-card csbs">
      <h3>🌊 Marine & Offshore Engineering</h3>
      <p>Mechanics of underwater drones, offshore energy rigs, and ocean sustainability technologies will grow rapidly.</p>
    </div>

  </div>
</section>

</body>
</html>

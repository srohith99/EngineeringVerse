<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - Biotechnology</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Biotech Startups</div>
  <ul class="nav-links">
    <li><a href="bio.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 From Labs to Startups</span>
    <h1>Innovative Biotech Startup Ideas</h1>
  </div>
</section>

<section class="branches">
  <h2>Startup Possibilities in Biotechnology</h2>
  <div class="branch-grid">

    <div class="branch-card bio">
      <h3>🧬 CRISPR Therapy Solutions</h3>
      <p>Startup providing customized gene-editing services for inherited diseases using CRISPR-Cas9 and next-gen sequencing.</p>
    </div>

    <div class="branch-card chem">
      <h3>🌿 Plant-Based Meat</h3>
      <p>Use synthetic biology and biofermentation to create sustainable, protein-rich plant alternatives to meat.</p>
    </div>

    <div class="branch-card mech">
      <h3>🔬 At-Home Diagnostic Kits</h3>
      <p>Affordable biotech devices for real-time health tracking — glucose, cholesterol, fertility, or infectious disease detection.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🧫 Microbiome Analysis Platform</h3>
      <p>A gut health analytics startup offering personalized diet recommendations based on gut bacteria analysis using AI.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>🧪 Cloud-Based Bio Labs</h3>
      <p>Platform that lets students and researchers simulate experiments virtually, saving lab costs and materials.</p>
    </div>

    <div class="branch-card eee">
      <h3>🌾 Smart Agri-Biotech Systems</h3>
      <p>AI & IoT-based soil nutrition and crop quality monitoring systems using genetically optimized seeds and microbes.</p>
    </div>

  </div>
</section>

</body>
</html>

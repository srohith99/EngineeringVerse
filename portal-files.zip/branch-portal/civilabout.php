<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Civil Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVIGATION -->
  <nav class="navbar">
    <div class="logo">📖 About Civil</div>
    <ul class="nav-links">
      <li><a href="civil.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- ABOUT SECTION -->
  <section class="branches">
    <h2>Introduction to Civil Engineering</h2>
    <div class="branch-grid">

      <div class="branch-card civil">
        <h3>🧱 What is Civil Engineering?</h3>
        <p>
          Civil Engineering is one of the oldest branches of engineering that deals with the design, construction, and maintenance of the physical and naturally built environment. It includes infrastructure like roads, bridges, canals, dams, buildings, and airports.
        </p>
      </div>

      <div class="branch-card mech">
        <h3>📚 Core Subjects</h3>
        <p>
          - Structural Engineering<br>
          - Transportation Engineering<br>
          - Geotechnical Engineering<br>
          - Environmental Engineering<br>
          - Construction Management<br>
          - Water Resources Engineering
        </p>
      </div>

      <div class="branch-card eee">
        <h3>🏗️ Applications & Industries</h3>
        <p>
          Civil Engineers work in public and private sectors including construction firms, transportation departments, urban planning, water treatment plants, infrastructure planning, and disaster management.
        </p>
      </div>

      <div class="branch-card chem">
        <h3>👷 Roles & Responsibilities</h3>
        <p>
          - Planning and designing infrastructure<br>
          - Site inspection and supervision<br>
          - Ensuring safety and sustainability<br>
          - Managing materials and labor<br>
          - Adhering to environmental and legal norms
        </p>
      </div>

    </div>
  </section>

</body>
</html>

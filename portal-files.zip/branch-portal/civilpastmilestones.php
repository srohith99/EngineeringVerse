<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - Civil Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">📚 Civil History</div>
    <ul class="nav-links">
      <li><a href="civil.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HERO SECTION -->
  <section class="hero-section">
    <div class="hero-glass">
      <span>🏛️ Learn from the Legends</span>
      <h1>Historic Milestones in Civil Engineering</h1>
    </div>
  </section>

  <!-- MILESTONES GRID -->
  <section class="branches">
    <h2>Engineering That Changed the World</h2>
    <div class="branch-grid">

      <div class="branch-card civil">
        <h3>🏗️ Great Pyramids of Giza (2560 BC)</h3>
        <p>Among the earliest examples of monumental civil design, built with extreme precision and alignment to celestial bodies.</p>
      </div>

      <div class="branch-card mech">
        <h3>🌉 Roman Aqueducts (312 BC)</h3>
        <p>Advanced water transport systems showcasing Roman mastery of arches, gravity flow, and concrete use.</p>
      </div>

      <div class="branch-card chem">
        <h3>🚢 Panama Canal (1914)</h3>
        <p>One of the greatest feats in transportation infrastructure — connecting oceans, revolutionizing trade routes.</p>
      </div>

      <div class="branch-card cseds">
        <h3>🗼 Burj Khalifa (2010)</h3>
        <p>The tallest structure ever built — a marvel of materials, wind engineering, and vertical load design.</p>
      </div>

      <div class="branch-card aiml">
        <h3>🏞️ Three Gorges Dam (2012)</h3>
        <p>World’s largest hydroelectric project showcasing power of civil engineering in energy and flood control.</p>
      </div>

      <div class="branch-card eee">
        <h3>🚆 Channel Tunnel (1994)</h3>
        <p>A 50.5 km rail tunnel beneath the English Channel — a triumph of tunneling and international collaboration.</p>
      </div>

    </div>
  </section>

</body>
</html>

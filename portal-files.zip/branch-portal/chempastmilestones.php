<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - Chemical Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Chemical History</div>
  <ul class="nav-links">
    <li><a href="chem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Historical Timeline</span>
    <h1>Milestones in Chemical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>Breakthroughs That Shaped the Field</h2>
  <div class="branch-grid">

    <div class="branch-card chem">
      <h3>⚗️ Haber-Bosch Process (1909)</h3>
      <p>Enabled large-scale ammonia synthesis, revolutionizing fertilizers and food production worldwide.</p>
    </div>

    <div class="branch-card mech">
      <h3>🛢️ Petroleum Refining Advances</h3>
      <p>Fractional distillation and catalytic cracking laid the foundation for the global fuel and plastics industries.</p>
    </div>

    <div class="branch-card bio">
      <h3>🧫 Birth of Biochemical Engineering</h3>
      <p>Fermentation for penicillin & insulin production changed medicine and the biotech industry forever.</p>
    </div>

    <div class="branch-card cseds">
      <h3>📊 Process Simulation Software</h3>
      <p>Tools like ASPEN and HYSYS enabled engineers to model, optimize, and test plant designs virtually.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>⚙️ Polymer Engineering Era</h3>
      <p>Discovery and mass production of synthetic polymers like nylon and PVC revolutionized manufacturing and textiles.</p>
    </div>

    <div class="branch-card eee">
      <h3>🌍 Environmental Engineering Focus</h3>
      <p>Awareness and legislation in the 1970s drove research into pollution control and green chemical alternatives.</p>
    </div>

  </div>
</section>

</body>
</html>

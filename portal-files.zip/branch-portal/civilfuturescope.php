<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - Civil Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">📈 Civil Future</div>
    <ul class="nav-links">
      <li><a href="civil.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HERO SECTION -->
  <section class="hero-section">
    <div class="hero-glass">
      <span>🚀 What's Next?</span>
      <h1>The Future of Civil Engineering</h1>
    </div>
  </section>

  <!-- FUTURE SCOPE CONTENT -->
  <section class="branches">
    <h2>Emerging Opportunities by 2030+</h2>
    <div class="branch-grid">

      <div class="branch-card civil">
        <h3>🏙️ AI-Driven Urban Planning</h3>
        <p>Future cities will use AI to design roads, buildings, and utilities with real-time data and minimal environmental impact.</p>
      </div>

      <div class="branch-card cseds">
        <h3>🏗️ Self-Healing Materials</h3>
        <p>Concrete that heals cracks automatically using bacteria or polymers could dramatically increase structure longevity.</p>
      </div>

      <div class="branch-card aiml">
        <h3>🔮 Quantum & Nano Engineering</h3>
        <p>Quantum sensors may detect micro-vibrations in infrastructure, while nanotech coatings reduce pollution and erosion.</p>
      </div>

      <div class="branch-card chem">
        <h3>♻️ Carbon-Negative Buildings</h3>
        <p>Innovations like CO₂-absorbing concrete and sustainable wood are enabling structures that offset environmental damage.</p>
      </div>

      <div class="branch-card eee">
        <h3>🌐 Digital Twins</h3>
        <p>Digital replicas of entire construction sites will be used for simulation, testing, and remote site monitoring.</p>
      </div>

      <div class="branch-card mech">
        <h3>🛰️ Space Infrastructure</h3>
        <p>With missions to Mars and the Moon, civil engineers will contribute to designing habitats and launchpads in space.</p>
      </div>

    </div>
  </section>

</body>
</html>

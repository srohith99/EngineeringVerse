<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - AIDD</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">AIDD Future</div>
  <ul class="nav-links">
    <li><a href="aidd.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Looking Ahead</span>
    <h1>The Future of AI & DS</h1>
  </div>
</section>

<section class="branches">
  <h2>What Lies Ahead</h2>
  <div class="branch-grid">

    <div class="branch-card aidd">
      <h3>🧪 Synthetic Data</h3>
      <p>AI-generated data will replace real datasets for training, increasing privacy and model quality.</p>
    </div>

    <div class="branch-card mech">
      <h3>🌐 AI-Driven Data Governance</h3>
      <p>Automated compliance, lineage tracking, and data cataloging with AI assistance.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🧠 Augmented Intelligence</h3>
      <p>AI that assists (not replaces) humans — in education, healthcare, and decision-making environments.</p>
    </div>

    <div class="branch-card chem">
      <h3>⚡ LLMs for Enterprises</h3>
      <p>Large Language Models fine-tuned for company knowledge bases and internal process optimization.</p>
    </div>

    <div class="branch-card bio">
      <h3>📶 Neuromorphic Computing</h3>
      <p>Hardware chips inspired by the human brain to supercharge data processing and inference speed.</p>
    </div>

  </div>
</section>

</body>
</html>

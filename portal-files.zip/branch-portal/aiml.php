<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AI & Machine Learning - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">AI & ML</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="aimlabout.php">📚 About AIML</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Welcome to</span>
    <h1>AI & Machine Learning</h1>
  </div>
</section>

<section class="branches">
  <h2>What You'll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card aiml">
      <h3><a href="aimlcurrenttrends.php">🔥 Current Trends</a></h3>
      <p>Deep Learning, Generative AI, NLP, Reinforcement Learning, Federated Learning</p>
    </div>

    <div class="branch-card aidd">
      <h3><a href="aimlstartups.php">💡 Startup Ideas</a></h3>
      <p>AI tutors, medical image analysis, ML ops tools, voice AI, legal tech AI platforms</p>
    </div>

    <div class="branch-card cseds">
      <h3><a href="aimlfuturescope.php">📈 Future Scope</a></h3>
      <p>Explainable AI, AI ethics, Artificial General Intelligence, edge AI, Neuro-symbolic learning</p>
    </div>

    <div class="branch-card bio">
      <h3><a href="aimlpastmilestones.php">📚 Past Milestones</a></h3>
      <p>Symbolic AI, ML evolution, DeepMind breakthroughs, Transformer models, AI winters</p>
    </div>

  </div>
</section>

</body>
</html>

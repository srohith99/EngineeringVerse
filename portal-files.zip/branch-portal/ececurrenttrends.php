<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - ECE </title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <nav class="navbar">
    <div class="logo">ECE Trends</div>
    <ul class="nav-links">
      <li><a href="ece.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>
  <!-- HEADER & WELCOME -->
  <section class="hero-section">
    <h1>Current Trends in ECE</h1>
    <div class="hero-glass">
      <span>👋 Hello, <?php echo $_SESSION['user']; ?>!</span>
      <p>Explore the top evolving technologies that are driving the ECE industry forward in 2025 and beyond.</p>
    </div>
  </section>

  <section class="branches">
    <h2>Trending Technologies in ECE (2025)</h2>
    <div class="branch-grid">

      <div class="branch-card ece">
        <h3>📡 5G & 6G Communication</h3>
        <p>Next-gen networks are redefining bandwidth, latency, and IoT reach.</p>
      </div>

      <div class="branch-card bio">
        <h3>🔧 Embedded Systems & IoT</h3>
        <p>Microcontrollers, sensors, and real-time OS power modern smart devices.</p>
      </div>

      <div class="branch-card cseds">
        <h3>📐 VLSI & Chip Design</h3>
        <p>Semiconductor design is booming, with AI-driven EDA tools gaining popularity.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🎧 Signal Processing & DSP</h3>
        <p>Audio/video optimization, biomedical signal systems, and neural decoding.</p>
      </div>

    </div>
  </section>

</body>
</html>

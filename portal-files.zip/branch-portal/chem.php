<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Chemical Engineering - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Chemical Engineering</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="chemabout.php">📚 About Chemical</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Welcome to</span>
    <h1>Chemical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>What You'll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card chem">
      <h3><a href="chemcurrenttrends.php">🔥 Current Trends</a></h3>
      <p>Green chemistry, nanomaterials, biochemical engineering, sustainable fuels, process automation</p>
    </div>

    <div class="branch-card cseiot">
      <h3><a href="chemstartups.php">💡 Startup Ideas</a></h3>
      <p>Bio-based plastic firms, water purification solutions, carbon capture systems, smart reactors</p>
    </div>

    <div class="branch-card mech">
      <h3><a href="chemfuturescope.php">📈 Future Scope</a></h3>
      <p>Smart process plants, hydrogen economy, enzyme engineering, AI-driven reaction modeling</p>
    </div>

    <div class="branch-card bio">
      <h3><a href="chempastmilestones.php">📚 Past Milestones</a></h3>
      <p>Petroleum refining, Haber process, polymer revolutions, thermodynamic modeling, catalyst discovery</p>
    </div>

  </div>
</section>

</body>
</html>

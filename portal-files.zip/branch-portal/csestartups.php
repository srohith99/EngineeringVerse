<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSE Startup Ideas</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">CSE Startups</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="cse.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- WELCOME HEADER -->
  <section class="hero-section">
    <h1>Startup Ideas for Computer Science Students</h1>
    <div class="hero-glass">
      <span>👨‍💻 Welcome, <?php echo $_SESSION['user']; ?>!</span>
      <p>Explore innovative and real-world startup ideas built using Computer Science skills.</p>
    </div>
  </section>

  <!-- IDEAS SECTION -->
  <section class="branches">
    <h2>Top Startup Ideas in 2025</h2>
    <div class="branch-grid">

      <div class="branch-card aiml">
        <h3>🤖 AI Career Assistant</h3>
        <p>An ML-powered app that guides students with resume feedback, job matches, and interview prep.</p>
      </div>

      <div class="branch-card cseds">
        <h3>📊 Data Visualization SaaS</h3>
        <p>Build a tool for startups and teachers to visualize CSV/Excel data instantly using charts & dashboards.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🔐 Student CyberShield</h3>
        <p>Develop browser extensions or mobile apps to protect students from phishing, scams, and tracking.</p>
      </div>

      <div class="branch-card csbs">
        <h3>💼 Peer-to-Peer Freelance Network</h3>
        <p>Create a secure platform for CSE students to offer freelance services (web dev, automation, etc).</p>
      </div>

      <div class="branch-card cse">
        <h3>🧠 Learning Tracker with AI</h3>
        <p>Smart planner app that adjusts study goals with deadlines, progress, and motivational nudges.</p>
      </div>

      <div class="branch-card aidd">
        <h3>📚 Notes Sharing & AI Q&A</h3>
        <p>A platform where CSE students upload notes and an AI bot answers questions from them instantly.</p>
      </div>

    </div>
  </section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - Mechanical</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">💡 Mech Startups</div>
  <ul class="nav-links">
    <li><a href="mech.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 Build the Future</span>
    <h1>Startup Ideas in Mechanical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>Innovative Business Ideas</h2>
  <div class="branch-grid">

    <div class="branch-card csbs">
      <h3>🖨️ 3D Printing Services</h3>
      <p>Provide rapid prototyping for startups, hospitals, and design teams with a fleet of precision 3D printers.</p>
    </div>

    <div class="branch-card mech">
      <h3>🔋 EV Conversion Kits</h3>
      <p>Create affordable electric kits to convert petrol bikes or autos into EVs — perfect for the Indian market.</p>
    </div>

    <div class="branch-card eee">
      <h3>🛠️ Predictive Maintenance Tools</h3>
      <p>Use vibration sensors and AI models to predict machinery failures for industries using heavy equipment.</p>
    </div>

    <div class="branch-card bio">
      <h3>🏭 Smart Farming Robots</h3>
      <p>Autonomous seeders, weed detectors, and harvesters built using affordable mechanical + sensor systems.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🚛 Cold Chain Transport</h3>
      <p>Design thermally-insulated, IoT-tracked cargo for safe delivery of medical or food goods in rural areas.</p>
    </div>

    <div class="branch-card civil">
      <h3>🧊 HVAC Consultancy</h3>
      <p>Design and optimize cooling systems for buildings and data centers using sustainable thermal practices.</p>
    </div>

  </div>
</section>

</body>
</html>

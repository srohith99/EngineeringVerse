<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSE (IoT, Cyber Security & Blockchain)</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">CSE - IoT, Cyber & Blockchain</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="cseiotabout.php">📚 About</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>Welcome to Your Domain:</span>
    <h1>CSE – IoT, Cyber Security & Blockchain</h1>
    <p>A future-driven specialization bridging secure networks, smart devices, and decentralized systems. This is where technology, trust, and intelligence meet.</p>
  </div>
</section>

<!-- BRANCH MODULES -->
<section class="branches">
  <h2>What You’ll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card cseiot">
      <h3><a href="cseiotcurrenttrends.php">🔥 Current Trends</a></h3>
      <p>AI-driven threat detection, Zero Trust Networks, Secure IoT Mesh, Blockchain transparency, and digital forensics.</p>
    </div>

    <div class="branch-card aiml">
      <h3><a href="cseiotstartups.php">💡 Startup Ideas</a></h3>
      <p>Smart surveillance, IoT-enabled logistics, blockchain-based health records, threat simulation SaaS, and token-based identity verification.</p>
    </div>

    <div class="branch-card aidd">
      <h3><a href="cseiotfuturescope.php">📈 Future Scope</a></h3>
      <p>Quantum-resilient systems, blockchain in supply chain, predictive IoT analytics, and AI in threat hunting.</p>
    </div>

    <div class="branch-card csbs">
      <h3><a href="cseiotpastmilestones.php">📚 Past Milestones</a></h3>
      <p>Birth of IoT (1999), Bitcoin's whitepaper (2008), Mirai botnet (2016), GDPR (2018), and Web3 revolutions.</p>
    </div>

  </div>
</section>

</body>
</html>

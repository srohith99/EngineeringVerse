<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSE - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVIGATION -->
  <nav class="navbar">
    <div class="logo">🌐 CSE Branch</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="cseabout.php">📚 About</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HERO SECTION -->
  <section class="hero-section">
    <div class="hero-glass">
      <h1>👋 Hello, <?php echo $_SESSION['user']; ?>!</h1>
      <p>Welcome to <strong>Computer Science & Engineering</strong> – where logic meets innovation.</p>
      <p class="tagline">Explore current trends, startup ideas, career paths & more in CSE!</p>
    </div>
  </section>

  <!-- CARDS SECTION -->
  <section class="branches">
    <h2>✨ Explore Topics</h2>
    <div class="branch-grid">

      <a href="csecurrenttrends.php" class="branch-card cse">
        <h3>🔥 Current Trends</h3>
        <p>AI/ML, DevOps, Web3, Cloud, Cybersecurity & more.</p>
      </a>

      <a href="csestartups.php" class="branch-card aiml">
        <h3>💡 Startup Ideas</h3>
        <p>Innovate with SaaS, IoT, EdTech, bots & services.</p>
      </a>

      <a href="csefuturescope.php" class="branch-card cseds">
        <h3>📈 Future Scope</h3>
        <p>Quantum, BCI, AI 2.0, Smart Contracts, Neural Web.</p>
      </a>

      <a href="csepastmilestones.php" class="branch-card aidd">
        <h3>📚 Past Milestones</h3>
        <p>Explore 75+ years of computing breakthroughs.</p>
      </a>

    </div>
  </section>

</body>
</html>

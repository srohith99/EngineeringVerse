<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - CSE (IoT, Cyber & Blockchain)</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">CSE-IoT: Legacy Timeline</div>
  <ul class="nav-links">
    <li><a href="cseiot.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>Where It All Began</span>
    <h1>Historic Milestones in IoT, Cybersecurity & Blockchain</h1>
    <p>A timeline of breakthroughs that shaped today’s connected and secure digital world.</p>
  </div>
</section>

<!-- TIMELINE GRID -->
<section class="branches">
  <h2>Important Events & Breakthroughs</h2>
  <div class="branch-grid">

    <div class="branch-card eee">
      <h3>1969 – ARPANET</h3>
      <p>The foundation of the modern Internet — enabling connected systems and early networked communication.</p>
    </div>

    <div class="branch-card bio">
      <h3>1980s – Industrial Control Systems</h3>
      <p>SCADA and PLCs laid the groundwork for machine communication — roots of IoT.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>1999 – The Term "IoT" Coined</h3>
      <p>Kevin Ashton introduced “Internet of Things” in a presentation at P&G — vision for machine-to-machine interaction.</p>
    </div>

    <div class="branch-card cseds">
      <h3>2008 – Bitcoin Whitepaper</h3>
      <p>Satoshi Nakamoto published the blueprint for decentralized, peer-to-peer transactions — start of blockchain era.</p>
    </div>

    <div class="branch-card mech">
      <h3>2013 – Edward Snowden Revelations</h3>
      <p>Global focus shifted to privacy, surveillance, and the importance of end-to-end cybersecurity.</p>
    </div>

    <div class="branch-card ece">
      <h3>2016 – Mirai Botnet Attack</h3>
      <p>One of the largest IoT-based cyberattacks showed the critical need for IoT security protocols.</p>
    </div>

    <div class="branch-card chem">
      <h3>2018 – GDPR Enforced in EU</h3>
      <p>Data privacy and security standards began evolving globally — influencing security practices worldwide.</p>
    </div>

    <div class="branch-card aidd">
      <h3>2021 – Web3 Movement Emerges</h3>
      <p>Decentralized identity, DeFi, and DAOs started disrupting traditional tech platforms.</p>
    </div>

    <div class="branch-card aiml">
      <h3>2023 – AI + Blockchain Integration</h3>
      <p>AI models began being verified and run securely via blockchain-led smart auditing and decentralized AI layers.</p>
    </div>

  </div>
</section>

</body>
</html>

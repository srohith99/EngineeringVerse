<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ECE - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVIGATION -->
  <nav class="navbar">
    <div class="logo">ECE Branch</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="eceabout.php">📚 About ECE</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HEADER SECTION -->
  <section class="hero-section">
    <div class="hero-glass">
      <span>👋 Welcome, To!</span>
      <h1>Electronics & Communication Engineering</h1>
    </div>
  </section>

  <!-- CONTENT SECTION -->
  <section class="branches">
    <h2>What You'll Explore</h2>
    <div class="branch-grid">

      <div class="branch-card ece">
        <h3><a href="ececurrenttrends.php">📡 Current Trends</a></h3>
        <p>5G, Embedded Systems, VLSI, IoT, RF Communications</p>
      </div>

      <div class="branch-card cseds">
        <h3><a href="ecestartups.php">💡 Startup Ideas</a></h3>
        <p>Smart home solutions, IoT wearables, FPGA tech products</p>
      </div>

      <div class="branch-card aiml">
        <h3><a href="ecefuturescope.php">📈 Future Scope</a></h3>
        <p>6G, Satellite IoT, AI-on-chip, Neuromorphic Computing</p>
      </div>

      <div class="branch-card aidd">
        <h3><a href="ecepastmilestones.php">📚 Past Milestones</a></h3>
        <p>Evolution from analog to digital, microchip revolution, early IoT</p>
      </div>

    </div>
  </section>

</body>
</html>

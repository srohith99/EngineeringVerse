<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - AIML</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">AIML History</div>
  <ul class="nav-links">
    <li><a href="aiml.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>History of AI</span>
    <h1>Key Milestones in AI & ML</h1>
  </div>
</section>

<section class="branches">
  <h2>How We Got Here</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>💡 1956 – Birth of AI</h3>
      <p>At the Dartmouth Conference, AI was formally proposed as a research discipline.</p>
    </div>

    <div class="branch-card chem">
      <h3>🛑 AI Winters</h3>
      <p>Periods of reduced interest and funding in AI due to unmet expectations in the 1970s and late 1980s.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🎓 Rise of ML Algorithms</h3>
      <p>1980s–90s saw statistical learning, decision trees, SVMs, and ensemble methods evolve rapidly.</p>
    </div>

    <div class="branch-card aiml">
      <h3>🚀 Deep Learning Era</h3>
      <p>2012 ImageNet breakthrough by AlexNet sparked the deep learning revolution.</p>
    </div>

    <div class="branch-card bio">
      <h3>🧠 Transformer Models</h3>
      <p>Google’s BERT and OpenAI’s GPT reshaped natural language understanding with self-attention mechanisms.</p>
    </div>

  </div>
</section>

</body>
</html>

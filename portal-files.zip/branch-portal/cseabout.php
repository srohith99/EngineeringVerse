<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About CSE - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVIGATION -->
  <nav class="navbar">
    <div class="logo">About CSE</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="cse.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>


  <!-- ABOUT CONTENT -->
  <section class="branches">
    <h2>About the CSE Branch</h2>
    <div class="branch-grid">

      <div class="branch-card cse">
        <h3>📖 What is CSE?</h3>
        <p>Computer Science and Engineering combines the principles of computer science with electrical engineering to design, develop, and optimize software and hardware systems.</p>
      </div>

      <div class="branch-card cseds">
        <h3>🔍 Why Choose CSE?</h3>
        <p>CSE drives today’s digital transformation. It offers careers in software development, cybersecurity, AI, cloud computing, data science, and much more with global scope.</p>
      </div>

      <div class="branch-card aiml">
        <h3>🧠 What You'll Learn</h3>
        <p>Programming, Data Structures, Algorithms, DBMS, Networking, Operating Systems, AI, Web Dev, and Machine Learning are part of the core CSE curriculum.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🌐 Scope & Opportunities</h3>
        <p>CSE offers unmatched versatility — from working in global MNCs to building startups, and contributing to innovations in AI, Quantum, IoT, and Blockchain.</p>
      </div>

    </div>
  </section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About - EEE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">🔌 About EEE</div>
  <ul class="nav-links">
    <li><a href="eee.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>⚡ Powering the Modern World</span>
    <h1>What is Electrical & Electronics Engineering?</h1>
  </div>
</section>

<section class="branches">
  <h2>Overview</h2>
  <div class="branch-grid">
    <div class="branch-card eee">
      <p>EEE is the backbone of our electrified world. It blends the principles of electricity, electronics, and electromagnetism to develop systems that power everything — from homes and hospitals to rockets and renewable energy systems.</p>
      <p>This branch focuses on key domains like electrical machines, power systems, control systems, embedded systems, and renewable energy. It’s one of the most diversified engineering fields, offering applications across multiple industries including automotive, aerospace, defense, and energy.</p>
    </div>
  </div>
</section>

</body>
</html>

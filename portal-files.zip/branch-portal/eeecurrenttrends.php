<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - EEE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">⚡ EEE Trends</div>
  <ul class="nav-links">
    <li><a href="eee.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 Tech at the Edge</span>
    <h1>Current Trends in Electrical & Electronics</h1>
  </div>
</section>

<section class="branches">
  <h2>In-Demand Technologies in 2025</h2>
  <div class="branch-grid">

    <div class="branch-card eee">
      <h3>🔋 Smart Grids</h3>
      <p>Smart grids use IoT, sensors, and AI to manage electricity flow efficiently and reduce power loss. They help create a more resilient and responsive power infrastructure.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🚗 Electric Vehicles (EVs)</h3>
      <p>EEE is driving the transition to EVs with innovations in battery management systems, regenerative braking, and high-efficiency motors.</p>
    </div>

    <div class="branch-card chem">
      <h3>🔆 Renewable Energy Systems</h3>
      <p>Solar PV, wind turbines, and hybrid systems are now integrated with smart inverters, storage systems, and remote analytics.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>📶 IoT in Power Management</h3>
      <p>Smart meters and home automation tools are transforming energy usage tracking, billing, and conservation at the consumer level.</p>
    </div>

    <div class="branch-card aiml">
      <h3>⚙️ Industrial Automation</h3>
      <p>EEE engineers now work closely with AI and robotics to automate industries through PLCs, SCADA, and IIoT-based systems.</p>
    </div>

  </div>
</section>

</body>
</html>

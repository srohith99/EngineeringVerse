<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About AIML</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">About AI & ML</div>
  <ul class="nav-links">
    <li><a href="aiml.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Dive into</span>
    <h1>Artificial Intelligence & Machine Learning</h1>
  </div>
</section>

<section class="branches">
  <h2>What is AIML?</h2>
  <div class="branch-grid">

    <div class="branch-card aiml">
      <h3>🧠 AI vs ML</h3>
      <p>AI is the broad concept of machines mimicking human intelligence. ML is a subset where machines learn from data to improve over time.</p>
    </div>

    <div class="branch-card bio">
      <h3>🔧 Core Subjects</h3>
      <p>Data Structures, Algorithms, Probability, Statistics, Neural Networks, NLP, Deep Learning, Computer Vision</p>
    </div>

    <div class="branch-card mech">
      <h3>💻 Languages & Tools</h3>
      <p>Python, TensorFlow, PyTorch, Keras, Scikit-learn, OpenCV, NLTK, HuggingFace, Jupyter</p>
    </div>

    <div class="branch-card cseds">
      <h3>📊 Applications</h3>
      <p>Healthcare, Retail, Finance, Autonomous Vehicles, Education, Robotics, Entertainment, Cybersecurity</p>
    </div>

  </div>
</section>

</body>
</html>

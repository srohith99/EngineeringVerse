<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $branch = $_POST['branch'];

    $sql = "INSERT INTO users (full_name, email, password, branch)
            VALUES ('$full_name', '$email', '$password', '$branch')";

    if ($conn->query($sql) === TRUE) {
        header("Location: login.php");
        exit();
    } else {
        $error = "Something went wrong: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Signup</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="form-container">
    <form method="POST" action="">
      <h2>Sign Up</h2>
      <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
      <input type="text" name="full_name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <select name="branch" required>
        <option value="">Select Branch</option>
        <option value="CSE">CSE</option>
        <option value="ISE">ISE</option>
        <option value="AI & ML">AI & ML</option>
        <!-- Add more branches -->
      </select>
      <button type="submit">Sign Up</button>
      <p>Already have an account? <a href="login.php">Login</a></p>
    </form>
  </div>
</body>
</html>

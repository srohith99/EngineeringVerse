<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About ISE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">About ISE</div>
  <ul class="nav-links">
    <li><a href="ise.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Explore the Core of</span>
    <h1>Information Science & Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>What is ISE?</h2>
  <div class="branch-grid">

    <div class="branch-card ise">
      <h3>📘 Overview</h3>
      <p>ISE is a field focused on managing, processing, and retrieving data through computation. It blends Computer Science with Information Systems and Human-Centered Computing.</p>
    </div>

    <div class="branch-card cse">
      <h3>💼 Core Areas</h3>
      <p>Data Mining, Information Retrieval, NLP, Web Semantics, Databases, Human-Computer Interaction, and Knowledge Engineering.</p>
    </div>

    <div class="branch-card bio">
      <h3>🎯 Why it Matters?</h3>
      <p>ISE is key to building intelligent systems that understand and organize the world’s information — powering everything from search engines to decision support tools.</p>
    </div>

    <div class="branch-card chem">
      <h3>🧠 Career Domains</h3>
      <p>Data Scientist, Cloud Engineer, Business Intelligence Analyst, Software Engineer, Database Administrator, Information Architect.</p>
    </div>

  </div>
</section>

</body>
</html>

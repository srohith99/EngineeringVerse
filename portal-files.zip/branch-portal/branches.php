<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Engineering Branches</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVIGATION -->
  <nav class="navbar">
    <div class="logo">🌐 Engineering Branches</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="about.php">📚 About</a></li>
      <li><a href="contact.php">📞 Contact</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- BRANCH GRID -->
  <section class="branches">
    <h2>Available Engineering Branches</h2>
    <div class="branch-grid">

      <a href="cse.php" class="branch-card cse">Computer Science & Engineering</a>
      <a href="#" class="branch-card ise">Information Science & Engineering</a>
      <a href="#" class="branch-card mech">Mechanical Engineering</a>
      <a href="#" class="branch-card civil">Civil Engineering</a>
      <a href="#" class="branch-card ece">Electronics & Communication Engineering</a>
      <a href="#" class="branch-card eee">Electrical & Electronics Engineering</a>
      <a href="#" class="branch-card iem">Industrial Engineering & Management</a>
      <a href="#" class="branch-card chem">Chemical Engineering</a>
      <a href="#" class="branch-card bio">Biotechnology</a>
      <a href="#" class="branch-card aiml">Artificial Intelligence & Machine Learning</a>
      <a href="#" class="branch-card aidd">AI & Data Science</a>
      <a href="#" class="branch-card cseds">CSE (Data Science)</a>
      <a href="#" class="branch-card cseiot">CSE (IoT & Cyber Security + Blockchain)</a>
      <a href="#" class="branch-card csbs">CSE (Business Systems)</a>

    </div>
  </section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>EEE - Electrical & Electronics Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">🔌 EEE Branch</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="eeeabout.php">📘 About</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>👋 Welcome, <?php echo $_SESSION['user']; ?>!</span>
    <h1>Electrical & Electronics Engineering</h1>
  </div>
</section>

<!-- CONTENT SECTION -->
<section class="branches">
  <h2>What You'll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card eee">
      <h3><a href="eeecurrenttrends.php">⚡ Current Trends</a></h3>
      <p>Smart Grids, Electric Vehicles, IoT in Power Systems, Solar Power, Power Electronics</p>
    </div>

    <div class="branch-card aiml">
      <h3><a href="eeestartups.php">💡 Startup Ideas</a></h3>
      <p>EV conversion kits, solar microgrids, smart meters, energy audit automation</p>
    </div>

    <div class="branch-card cseds">
      <h3><a href="eeefuturescope.php">📈 Future Scope</a></h3>
      <p>Grid automation, wireless power transfer, AI-integrated power systems, energy storage tech</p>
    </div>

    <div class="branch-card chem">
      <h3><a href="eeepastmilestones.php">📚 Past Milestones</a></h3>
      <p>AC/DC evolution, invention of transistor, development of microcontrollers & digital systems</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - CSBS</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">CSBS Startups</div>
  <ul class="nav-links">
    <li><a href="csbs.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 Entrepreneur Mindset</span>
    <h1>Startup Ideas for CSBS Students</h1>
    <p>Combine business knowledge with tech power — these startup ideas are tailor-fit for CSBS minds.</p>
  </div>
</section>

<!-- IDEAS SECTION -->
<section class="branches">
  <h2>Top Startup Opportunities</h2>
  <div class="branch-grid">

    <div class="branch-card csbs">
      <h3>📊 Business Intelligence Dashboards</h3>
      <p>Create customizable BI platforms for SMEs to track inventory, sales, and finance in real-time.</p>
    </div>

    <div class="branch-card chem">
      <h3>💼 Automated Payroll & HR Software</h3>
      <p>Build SaaS tools to handle recruitment, salary, appraisal, and leave management for growing startups.</p>
    </div>

    <div class="branch-card aiml">
      <h3>🤖 AI-Powered Customer Service</h3>
      <p>Develop AI bots that reduce call center costs and improve response accuracy using NLP + ML.</p>
    </div>

    <div class="branch-card cseds">
      <h3>📈 Investment Tracker App</h3>
      <p>A user-friendly financial tracker for stocks, crypto, and mutual funds using real-time analytics.</p>
    </div>

    <div class="branch-card bio">
      <h3>🛍️ Retail & Supply Chain Analytics</h3>
      <p>Build platforms that help businesses forecast demand, manage inventory, and optimize supply chains.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>📬 Automated Invoice Management</h3>
      <p>Simplify B2B invoice generation and payment tracking using cloud APIs + blockchain.</p>
    </div>

    <div class="branch-card eee">
      <h3>🎓 Online Certification Platforms</h3>
      <p>Launch niche upskilling platforms for finance-tech, HR analytics, and business automation tools.</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - CSE (IoT, Cyber & Blockchain)</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">Startups – CSE-IoT</div>
  <ul class="nav-links">
    <li><a href="cseiot.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 Startup Ready?</span>
    <h1>Ideas in IoT, Cyber & Blockchain</h1>
    <p>Blend innovation with practicality. These startup ideas are built for scalability and impact.</p>
  </div>
</section>

<!-- IDEAS GRID -->
<section class="branches">
  <h2>Top Startup Ideas to Explore</h2>
  <div class="branch-grid">

    <div class="branch-card cseiot">
      <h3>📡 Smart Campus Automation</h3>
      <p>Use IoT sensors and mobile dashboards to monitor energy, attendance, room occupancy, and waste management in colleges.</p>
    </div>

    <div class="branch-card chem">
      <h3>🔐 Personal Cybersecurity Suite</h3>
      <p>Offer a freemium app that scans devices for phishing, data leaks, and performs secure backup + VPN combo.</p>
    </div>

    <div class="branch-card cseds">
      <h3>⛓️ Blockchain-Powered Certificates</h3>
      <p>Digitally issue academic or legal documents on the blockchain to prevent forgery and enable global verification.</p>
    </div>

    <div class="branch-card ece">
      <h3>👁️ AI-Driven Intrusion System</h3>
      <p>Create edge-AI cameras or IoT motion devices for smart homes to detect and alert suspicious activity instantly.</p>
    </div>

    <div class="branch-card aiml">
      <h3>🌍 Climate Sensor Grid</h3>
      <p>Develop low-power weather and pollution monitoring kits connected via LoRaWAN for remote data collection.</p>
    </div>

    <div class="branch-card mech">
      <h3>💠 Supply Chain with Blockchain</h3>
      <p>A platform that tracks goods from manufacturer to customer using blockchain for transparency and authenticity.</p>
    </div>

    <div class="branch-card aidd">
      <h3>📶 IoT Smart Healthcare Devices</h3>
      <p>Build wearable ECG or blood sugar monitors that connect to mobile apps for patient tracking and alerts.</p>
    </div>

    <div class="branch-card civil">
      <h3>🧠 Cybersecurity Awareness Platform</h3>
      <p>Gamified learning portal for teens and corporates to understand phishing, malware, and data security hygiene.</p>
    </div>

  </div>
</section>

</body>
</html>

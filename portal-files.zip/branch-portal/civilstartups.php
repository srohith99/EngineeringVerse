<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - Civil Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">💡 Civil Startups</div>
    <ul class="nav-links">
      <li><a href="civil.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HERO SECTION -->
  <section class="hero-section">
    <div class="hero-glass">
      <span>💡 Think, Build, Innovate</span>
      <h1>Startup Opportunities in Civil Engineering</h1>
    </div>
  </section>

  <!-- STARTUP IDEAS GRID -->
  <section class="branches">
    <h2>Startup Concepts for the Real World</h2>
    <div class="branch-grid">

      <div class="branch-card bio">
        <h3>♻️ EcoBrick Solutions</h3>
        <p>Build bricks using recycled plastics and industrial waste for affordable and green construction materials.</p>
      </div>

      <div class="branch-card mech">
        <h3>🛠️ Modular Housing Units</h3>
        <p>Create prefabricated homes that are fast to assemble, cost-effective, and ideal for rural housing projects.</p>
      </div>

      <div class="branch-card chem">
        <h3>🧪 Smart Concrete Mix Labs</h3>
        <p>Offer mobile labs that test and recommend optimal concrete mixtures for strength and environmental impact.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🚧 AI-Powered Site Safety</h3>
        <p>Use computer vision and machine learning to detect safety violations and risky behavior on construction sites in real time.</p>
      </div>

      <div class="branch-card csbs">
        <h3>📊 Project Analytics Platform</h3>
        <p>Build a SaaS tool for real-time construction tracking, delay analysis, and cost forecasting.</p>
      </div>

      <div class="branch-card eee">
        <h3>🚁 Drone Surveying Services</h3>
        <p>Offer high-resolution aerial mapping for land surveys, bridge inspections, and structural monitoring.</p>
      </div>

    </div>
  </section>

</body>
</html>

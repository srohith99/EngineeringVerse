<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - CSDS</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Future Scope</div>
  <ul class="nav-links">
    <li><a href="csds.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>What’s Coming?</span>
    <h1>Future of Data Science</h1>
  </div>
</section>

<section class="branches">
  <h2>Emerging Possibilities</h2>
  <div class="branch-grid">

    <div class="branch-card csbs">
      <h3>🌐 Federated Learning</h3>
      <p>Training ML models across decentralized edge devices without sharing raw data.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🧬 Synthetic Data Generation</h3>
      <p>AI-generated training data for building large, balanced datasets.</p>
    </div>

    <div class="branch-card eee">
      <h3>⏱️ Real-Time AI Inference</h3>
      <p>Low-latency model execution on devices with instant decisions at the edge.</p>
    </div>

    <div class="branch-card bio">
      <h3>🔀 Cross-Domain Data Fusion</h3>
      <p>Combining text, image, sensor & geo-data to create new insights.</p>
    </div>

  </div>
</section>

</body>
</html>

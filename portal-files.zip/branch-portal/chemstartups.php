<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - Chemical Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Chemical Startups</div>
  <ul class="nav-links">
    <li><a href="chem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🚀 From Labs to Market</span>
    <h1>Innovative Chemical Startup Ideas</h1>
  </div>
</section>

<section class="branches">
  <h2>Startup Opportunities in Chemical Engineering</h2>
  <div class="branch-grid">

    <div class="branch-card chem">
      <h3>🌿 Bio-Plastics Manufacturing</h3>
      <p>Startups developing eco-friendly alternatives to petroleum-based plastics using agricultural waste or algae-based feedstocks.</p>
    </div>

    <div class="branch-card bio">
      <h3>💧 Advanced Water Purification Systems</h3>
      <p>Low-energy, high-efficiency filtration systems using nanomaterials and biofilters for rural and industrial water supply.</p>
    </div>

    <div class="branch-card cseds">
      <h3>⚡ Clean Fuel Synthesis</h3>
      <p>Small-scale chemical reactors that convert CO₂ into methanol or green hydrogen for commercial use.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>📲 Smart Chemical Monitoring Devices</h3>
      <p>IoT-enabled portable devices for detecting contamination, pH, toxicity, and process leaks in real-time.</p>
    </div>

    <div class="branch-card mech">
      <h3>🏭 Modular Chemical Plants</h3>
      <p>Compact, mobile units for batch processing of chemicals – ideal for rural, remote, or disaster-hit zones.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🔬 AI-Driven Lab-as-a-Service</h3>
      <p>Cloud-connected labs offering remote-controlled experiments, AI-guided simulations, and chemical inventory analytics.</p>
    </div>

  </div>
</section>

</body>
</html>

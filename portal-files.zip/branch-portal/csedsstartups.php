<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startup Ideas - CSDS</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">CSDS Startups</div>
  <ul class="nav-links">
    <li><a href="csds.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Build the Future:</span>
    <h1>Top Startup Ideas</h1>
  </div>
</section>

<section class="branches">
  <h2>Promising Ideas</h2>
  <div class="branch-grid">

    <div class="branch-card aiml">
      <h3>🔎 AI-Powered Legal Research</h3>
      <p>Train NLP models to summarize and search case laws across legal databases.</p>
    </div>

    <div class="branch-card cseds">
      <h3>💉 Healthcare Predictions</h3>
      <p>Build tools that detect early signs of diseases using health records and ML models.</p>
    </div>

    <div class="branch-card mech">
      <h3>📦 Demand Forecasting</h3>
      <p>AI platforms for real-time inventory tracking and stock predictions in retail chains.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>🎯 AI Targeting Tools</h3>
      <p>Behavioral targeting engines for adtech and influencer-based marketing.</p>
    </div>

  </div>
</section>

</body>
</html>

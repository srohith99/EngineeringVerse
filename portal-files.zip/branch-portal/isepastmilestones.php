<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - ISE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">ISE Milestones</div>
  <ul class="nav-links">
    <li><a href="ise.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Looking Back</span>
    <h1>Major Milestones in ISE</h1>
  </div>
</section>

<section class="branches">
  <h2>Historic Moments That Shaped ISE</h2>
  <div class="branch-grid">

    <div class="branch-card cse">
      <h3>📁 File Systems & Operating Systems</h3>
      <p>The 1970s and 80s saw the development of Unix, FAT, and NTFS file systems — paving the way for digital data storage and structured information access.</p>
    </div>

    <div class="branch-card ise">
      <h3>📚 Relational Database Revolution</h3>
      <p>Dr. E. F. Codd’s 1970 paper laid the foundation for SQL and RDBMS like Oracle, MySQL, and PostgreSQL — crucial for structured data handling.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🌐 Internet & Web Evolution</h3>
      <p>In the 90s, the World Wide Web exploded, shifting focus from local information systems to global knowledge access. HTML, HTTP, and search engines emerged.</p>
    </div>

    <div class="branch-card mech">
      <h3>📦 ERP & Enterprise Information Systems</h3>
      <p>From 1990s onwards, ISE fueled ERP systems like SAP, enabling integrated enterprise data processing, supply chain, and finance analytics.</p>
    </div>

    <div class="branch-card bio">
      <h3>📈 Big Data & Hadoop Era</h3>
      <p>Post-2005, unstructured data exploded. Hadoop & NoSQL (MongoDB, Cassandra) allowed large-scale data storage and distributed querying.</p>
    </div>

    <div class="branch-card chem">
      <h3>🧠 AI & Natural Language Interfaces</h3>
      <p>With Siri (2011), Alexa (2014), and ChatGPT (2022), natural interaction with machines became possible, reshaping how information is accessed.</p>
    </div>

  </div>
</section>

</body>
</html>

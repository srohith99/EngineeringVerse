<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - CSBS</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">CSBS Trends</div>
  <ul class="nav-links">
    <li><a href="csbs.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>What's Hot in 2025?</span>
    <h1>Current Trends in CSBS</h1>
    <p>Business and technology are blending like never before. Here's how.</p>
  </div>
</section>

<section class="branches">
  <h2>2025 Key Trends</h2>
  <div class="branch-grid">

    <div class="branch-card csbs">
      <h3>💡 Business Analytics</h3>
      <p>Data-driven decision making, BI tools like Power BI & Tableau are must-knows for modern enterprises.</p>
    </div>

    <div class="branch-card aiml">
      <h3>🤖 Intelligent Automation</h3>
      <p>AI + RPA combo is automating workflows, HR, payroll, and customer service sectors globally.</p>
    </div>

    <div class="branch-card chem">
      <h3>📉 FinTech Systems</h3>
      <p>Modern digital payment platforms, micro-investment apps, and blockchain-based finance models.</p>
    </div>

    <div class="branch-card eee">
      <h3>🧾 ERP and CRM Evolution</h3>
      <p>Cloud-first ERP (like SAP S/4HANA) and customer experience tools are becoming the new default.</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - AIML</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">AIML Trends</div>
  <ul class="nav-links">
    <li><a href="aiml.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>2025 Trends</span>
    <h1>AI & ML Leading the Future</h1>
  </div>
</section>

<section class="branches">
  <h2>What's Hot Now</h2>
  <div class="branch-grid">

    <div class="branch-card aiml">
      <h3>🧠 Generative AI</h3>
      <p>Tools like ChatGPT, DALL·E and Midjourney are revolutionizing content creation, design, and automation.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>⚙️ Edge AI</h3>
      <p>Bringing AI to devices with real-time processing on smartphones, wearables, and smart cameras.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🔁 Reinforcement Learning</h3>
      <p>Used in robotics, gaming, and decision systems to train agents through rewards and penalties.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🧬 TinyML</h3>
      <p>Deploying lightweight ML models on microcontrollers for IoT, smart cities, and embedded systems.</p>
    </div>

    <div class="branch-card mech">
      <h3>🛡️ AI in Cybersecurity</h3>
      <p>Detecting threats, preventing phishing, and responding to attacks using AI-driven security systems.</p>
    </div>

  </div>
</section>

</body>
</html>

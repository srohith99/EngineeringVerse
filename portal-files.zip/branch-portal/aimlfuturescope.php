<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - AIML</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">AI & ML Future</div>
  <ul class="nav-links">
    <li><a href="aiml.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>The Road Ahead</span>
    <h1>Future Scope of AI & ML</h1>
  </div>
</section>

<section class="branches">
  <h2>What’s Coming Next</h2>
  <div class="branch-grid">

    <div class="branch-card aiml">
      <h3>🧠 Artificial General Intelligence</h3>
      <p>The pursuit of AGI – systems with human-like cognitive abilities – is accelerating research and innovation.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🌐 AI Ethics & Governance</h3>
      <p>Building fair, explainable, unbiased systems will be a key focus for global AI policies and development.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🤖 Robotics & AI Fusion</h3>
      <p>Intelligent robotics powered by ML are transforming healthcare, logistics, and manufacturing sectors.</p>
    </div>

    <div class="branch-card mech">
      <h3>⚡ Quantum Machine Learning</h3>
      <p>Combining quantum computing and ML to solve intractable problems in optimization and chemistry.</p>
    </div>

    <div class="branch-card bio">
      <h3>🧠 Neuro-symbolic AI</h3>
      <p>A hybrid approach blending neural nets with symbolic logic to enhance decision-making and reasoning.</p>
    </div>

  </div>
</section>

</body>
</html>

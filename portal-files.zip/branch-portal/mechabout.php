<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About - Mechanical Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">⚙️ About Mechanical</div>
  <ul class="nav-links">
    <li><a href="mech.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>📘 Overview</span>
    <h1>Mechanical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>What is Mechanical Engineering?</h2>
  <div class="branch-grid">
    <div class="branch-card mech">
      <p>
        Mechanical Engineering is one of the oldest and most versatile branches of engineering. It involves the design,
        development, and maintenance of mechanical systems. From machines and engines to HVAC systems and industrial robots, 
        mechanical engineers play a vital role in virtually every sector.
      </p>
      <p>
        Key domains include thermodynamics, fluid mechanics, materials science, kinematics, and robotics. With the rise of 
        automation and smart manufacturing, mechanical engineering is evolving rapidly to meet global innovation demands.
      </p>
    </div>
  </div>
</section>

</body>
</html>

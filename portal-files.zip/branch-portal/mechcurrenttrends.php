<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - Mechanical</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">🔥 Mech Trends</div>
  <ul class="nav-links">
    <li><a href="mech.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>📡 2025 and Beyond</span>
    <h1>Current Trends in Mechanical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>What's Transforming the Industry?</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>🤖 Robotics & Mechatronics</h3>
      <p>Integration of electronics and mechanics is leading to autonomous robots in manufacturing, healthcare, and defense.</p>
    </div>

    <div class="branch-card ece">
      <h3>💻 CAD/CAM/CAE Advancements</h3>
      <p>Cloud-based simulations and generative design using AI are enhancing product development cycles.</p>
    </div>

    <div class="branch-card csbs">
      <h3>🔋 Electric Vehicle (EV) Tech</h3>
      <p>Mechanical engineers play a central role in battery pack design, thermal management, and lightweight chassis engineering.</p>
    </div>

    <div class="branch-card aiml">
      <h3>⚙️ Industry 4.0 & Smart Manufacturing</h3>
      <p>IoT, predictive maintenance, and cyber-physical systems are optimizing mechanical production lines globally.</p>
    </div>

    <div class="branch-card chem">
      <h3>♻️ Sustainable Design & Materials</h3>
      <p>Green engineering practices include using biodegradable polymers and energy-efficient thermal systems.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🔧 Additive Manufacturing (3D Printing)</h3>
      <p>Custom parts and tools are now made faster and cheaper with advanced 3D metal printing technologies.</p>
    </div>

  </div>
</section>

</body>
</html>

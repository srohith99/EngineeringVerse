<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - CS & Business Systems</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<nav class="navbar">
  <div class="logo">Past Milestones - CS & Business Systems</div>
  <ul class="nav-links">
    <li><a href="csbs.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Welcome to CS & Business Systems</span>
    <h1>Past Milestones - CS & Business Systems</h1>
  </div>
</section>

<section class="branches">
  <h2>Content goes here for Past Milestones - CS & Business Systems</h2>
  <div class="branch-grid">
    <div class="branch-card csbs">
      <p>This section will be updated with relevant content for CS & Business Systems - Past Milestones - CS & Business Systems.</p>
    </div>
  </div>
</section>
</body>
</html>

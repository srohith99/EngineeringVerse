<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSE (Data Science) - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">CSE - Data Science</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="csedsabout.php">📚 About</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO -->
<section class="hero-section">
  <div class="hero-glass">
    <span>Welcome to</span>
    <h1>CSE (Data Science)</h1>
  </div>
</section>

<!-- CONTENT -->
<section class="branches">
  <h2>What You'll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card cseds">
      <h3><a href="csedscurrenttrends.php">🔥 Current Trends</a></h3>
      <p>Explainable AI, DataOps, ML pipelines, Augmented Analytics, Real-time Dashboards</p>
    </div>

    <div class="branch-card aidd">
      <h3><a href="csedsstartups.php">💡 Startup Ideas</a></h3>
      <p>AI search engines, Healthcare prediction tools, No-code ML platforms, Retail analytics</p>
    </div>

    <div class="branch-card aiml">
      <h3><a href="csedsfuturescope.php">📈 Future Scope</a></h3>
      <p>Data-centric AI, edge analytics, cross-domain data fusion, federated data training</p>
    </div>

    <div class="branch-card mech">
      <h3><a href="csedspastmilestones.php">📚 Past Milestones</a></h3>
      <p>Data mining era, MapReduce, NoSQL boom, rise of visualization & predictive modeling</p>
    </div>

  </div>
</section>

</body>
</html>

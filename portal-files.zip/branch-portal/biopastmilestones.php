<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - Biotechnology</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Biotech History</div>
  <ul class="nav-links">
    <li><a href="bio.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Looking Back</span>
    <h1>Historical Milestones in Biotechnology</h1>
  </div>
</section>

<section class="branches">
  <h2>Major Achievements in Biotech</h2>
  <div class="branch-grid">

    <div class="branch-card bio">
      <h3>🧬 Discovery of DNA (1953)</h3>
      <p>Watson and Crick revealed the double-helix structure of DNA — the foundation of modern biotechnology.</p>
    </div>

    <div class="branch-card chem">
      <h3>🧫 Production of Recombinant Insulin (1982)</h3>
      <p>Genentech developed human insulin using genetically engineered bacteria — first biotech drug approved by FDA.</p>
    </div>

    <div class="branch-card cse">
      <h3>🧪 Human Genome Project (1990–2003)</h3>
      <p>The complete mapping of human DNA opened doors to personalized medicine and advanced genomics research.</p>
    </div>

    <div class="branch-card mech">
      <h3>🌾 GMO Crops Introduction (1994)</h3>
      <p>First genetically modified crop (Flavr Savr tomato) was approved, boosting global agricultural biotechnology.</p>
    </div>

    <div class="branch-card eee">
      <h3>🧬 CRISPR-Cas9 Discovery (2012)</h3>
      <p>A revolutionary gene-editing tool enabling precise, cost-effective DNA modification across organisms.</p>
    </div>

    <div class="branch-card cseds">
      <h3>💉 mRNA Vaccine Breakthrough (2020)</h3>
      <p>Pfizer-BioNTech and Moderna launched mRNA vaccines during COVID-19 — changing the future of vaccine development forever.</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - Biotechnology</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Biotech Trends</div>
  <ul class="nav-links">
    <li><a href="bio.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Trending in 2025</span>
    <h1>Current Innovations in Biotech</h1>
  </div>
</section>

<section class="branches">
  <h2>Latest Developments in Biotechnology</h2>
  <div class="branch-grid">

    <div class="branch-card bio">
      <h3>🧬 CRISPR Gene Editing</h3>
      <p>CRISPR-Cas9 is revolutionizing genetic engineering by enabling precise editing of DNA in plants, animals, and humans.</p>
    </div>

    <div class="branch-card chem">
      <h3>💻 Bioinformatics & Genomics</h3>
      <p>Advanced computation is used to decode genetic data, aiding in disease prediction and drug development.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🌾 Agri-Biotechnology</h3>
      <p>Development of drought-resistant crops, vertical farming, and plant-based vaccines for agricultural innovation.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🧫 Synthetic Biology</h3>
      <p>Creating artificial cells and bio-systems for use in medicine, industry, and energy generation.</p>
    </div>

    <div class="branch-card mech">
      <h3>🧪 Bioprocess Engineering</h3>
      <p>Optimizing industrial production of enzymes, vaccines, antibiotics, and biologics at scale.</p>
    </div>

    <div class="branch-card cse">
      <h3>💊 Personalized Medicine</h3>
      <p>Therapies tailored to individual genetic makeup, improving treatment effectiveness and reducing side effects.</p>
    </div>

  </div>
</section>

</body>
</html>

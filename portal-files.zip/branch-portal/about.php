<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About - O V Yogeswar Reddy</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
    }

    .profile-box {
      max-width: 800px;
      margin: 100px auto 40px;
      padding: 30px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 20px;
      backdrop-filter: blur(20px);
      box-shadow: 0 0 20px rgba(0,255,255,0.1);
      color: #fff;
      text-align: center;
    }

    .profile-box h1 {
      color: #00ffff;
      font-size: 32px;
      margin-bottom: 10px;
    }

    .profile-box p {
      font-size: 16px;
      margin: 10px 0;
      color: #ccc;
    }

    .section-title {
      text-align: center;
      color: #00f2fe;
      margin: 50px 0 20px;
      font-size: 28px;
    }

    .about-cards {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 25px;
      padding: 0 30px 60px;
    }

    .about-card {
      width: 280px;
      background: rgba(255, 255, 255, 0.07);
      border-radius: 16px;
      padding: 20px;
      color: #fff;
      text-align: center;
      transition: 0.3s ease;
      border-left: 5px solid #00ffff;
    }

    .about-card:hover {
      background: linear-gradient(135deg, #00f2fe, #4facfe);
      color: #000;
      transform: scale(1.05);
    }

    footer {
      text-align: center;
      padding: 30px;
      color: #ccc;
      font-size: 14px;
    }
  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">About Me</div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li><a href="branches.php">Branches</a></li>
    <li><a href="contact.php">Contact</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- PERSONAL PROFILE BOX -->
<div class="profile-box">
  <h1>O V YOGESWAR REDDY</h1>
  <p>💡 Developer | 🧠 Thinker | 📘 Learner | 🧑‍💻 Engineer in Progress</p>
  <p>I'm passionate about bringing innovation to education and empowering students across every engineering discipline. This platform was designed and developed as a student-first initiative to help you explore your path clearly and confidently.</p>
</div>

<!-- SECTION: PLATFORM PURPOSE -->
<h2 class="section-title">Why This Platform Exists</h2>
<div class="about-cards">

  <div class="about-card">
    <h3>🎯 My Vision</h3>
    <p>To connect engineering education with the real world — through insights, startups, and future-ready thinking.</p>
  </div>

  <div class="about-card">
    <h3>📚 For All Branches</h3>
    <p>15 branches, 75+ detailed sections on trends, scope, milestones, and startup ideas — fully personalized.</p>
  </div>

  <div class="about-card">
    <h3>👨‍💻 Built with Tech</h3>
    <p>Crafted using HTML, CSS, JS, PHP, and MySQL with XAMPP for backend — lightweight and fast.</p>
  </div>

  <div class="about-card">
    <h3>🚀 Student Impact</h3>
    <p>Whether you’re in CS, Civil, BioTech or AIML — there’s value, clarity, and career insights for you here.</p>
  </div>

</div>

<!-- FOOTER -->
<footer>
  &copy; <?php echo date("Y"); ?> | Designed & Developed by <strong>O V Yogeswar Reddy</strong> 💻
</footer>

</body>
</html>

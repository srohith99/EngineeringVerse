<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - ISE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">ISE Future</div>
  <ul class="nav-links">
    <li><a href="ise.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Glance into Tomorrow</span>
    <h1>Future Scope of ISE</h1>
  </div>
</section>

<section class="branches">
  <h2>Where ISE is Headed</h2>
  <div class="branch-grid">

    <div class="branch-card ise">
      <h3>🧠 Explainable AI & Ethical Tech</h3>
      <p>ISE professionals will lead in making AI transparent, fair, and auditable in decision-making processes.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🔗 Intelligent Knowledge Networks</h3>
      <p>Future enterprise systems will automatically discover, connect, and contextualize information using advanced knowledge graphs.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>🤝 Human-AI Collaboration</h3>
      <p>ISE will bridge users and machines—designing systems that understand human needs and adapt dynamically.</p>
    </div>

    <div class="branch-card mech">
      <h3>⚙️ Automation with Responsibility</h3>
      <p>ISE will drive digital transformation where machines assist but never fully replace human roles.</p>
    </div>

    <div class="branch-card chem">
      <h3>🌍 Decentralized Information Systems</h3>
      <p>Blockchain + ISE = Trust-based data systems for governance, voting, and knowledge validation.</p>
    </div>

    <div class="branch-card bio">
      <h3>📡 Ambient Intelligence</h3>
      <p>Future interfaces will respond to context without explicit commands—ISE will power this ambient tech evolution.</p>
    </div>

  </div>
</section>

</body>
</html>

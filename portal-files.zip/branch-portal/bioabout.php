<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Biotechnology</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">About Biotech</div>
  <ul class="nav-links">
    <li><a href="bio.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Inside the World of</span>
    <h1>Biotechnology Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>Overview of Biotechnology</h2>
  <div class="branch-grid">

    <div class="branch-card bio">
      <h3>🧬 What is Biotechnology?</h3>
      <p>Biotechnology combines biology, chemistry, and technology to manipulate living organisms and biological systems for product innovation in health, agriculture, and industry.</p>
    </div>

    <div class="branch-card chem">
      <h3>🔍 Scope of Biotech</h3>
      <p>It spans areas like genetic engineering, microbiology, bioinformatics, pharmaceuticals, biofuels, and biomaterials.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🏥 Key Applications</h3>
      <p>Development of life-saving drugs, vaccine production, personalized medicine, environmental cleanup, crop improvement, and industrial enzymes.</p>
    </div>

    <div class="branch-card mech">
      <h3>🌱 Why it Matters?</h3>
      <p>With increasing global health and climate challenges, biotech offers eco-friendly and sustainable solutions across sectors.</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mechanical Engineering</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">⚙️ Mechanical Branch</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="mechabout.php">📘 About</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- HERO SECTION -->
  <section class="hero-section">
    <div class="hero-glass">
      <span>👋 Welcome, <?php echo $_SESSION['user']; ?>!</span>
      <h1>Mechanical Engineering Portal</h1>
    </div>
  </section>

  <!-- CONTENT SECTION -->
  <section class="branches">
    <h2>What You'll Explore</h2>
    <div class="branch-grid">

      <div class="branch-card mech">
        <h3><a href="mechcurrenttrends.php">🔥 Current Trends</a></h3>
        <p>Robotics, CAD/CAM, EVs, Mechatronics, Industrial Automation</p>
      </div>

      <div class="branch-card aiml">
        <h3><a href="mechstartups.php">💡 Startup Ideas</a></h3>
        <p>3D printing services, EV kits, predictive maintenance tools</p>
      </div>

      <div class="branch-card cseds">
        <h3><a href="mechfuturescope.php">📈 Future Scope</a></h3>
        <p>Smart factories, nanotech, autonomous vehicles, green tech</p>
      </div>

      <div class="branch-card chem">
        <h3><a href="mechpastmilestones.php">📚 Past Milestones</a></h3>
        <p>Steam engines, industrial revolution, CNC machines, automation</p>
      </div>

    </div>
  </section>

</body>
</html>

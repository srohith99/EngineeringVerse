<?php
session_start();

// Optional: Replace with actual admin check
if (!isset($_SESSION['user']) || $_SESSION['user'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Connect to DB
$conn = new mysqli("localhost", "root", "", "engineering_portal");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch messages
$sql = "SELECT * FROM contact_messages ORDER BY submitted_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Panel - Messages</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .admin-table {
      margin-top: 50px;
      width: 90%;
      margin-left: auto;
      margin-right: auto;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 15px;
      overflow: hidden;
      backdrop-filter: blur(10px);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      color: #fff;
    }

    th, td {
      padding: 12px 16px;
      text-align: left;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    th {
      background-color: rgba(0, 255, 255, 0.1);
    }

    tr:hover {
      background-color: rgba(255, 255, 255, 0.05);
    }
  </style>
</head>
<body>

  <!-- NAVIGATION -->
  <nav class="navbar">
    <div class="logo">👨‍💻 Admin Panel</div>
    <ul class="nav-links">
      <li><a href="home.php">🏠 Home</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <section class="admin-table">
    <h2 style="text-align:center; padding:20px;">📬 Received Messages</h2>
    <table>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Message</th>
        <th>Submitted At</th>
      </tr>

      <?php if ($result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $row['id']; ?></td>
            <td><?= htmlspecialchars($row['name']); ?></td>
            <td><?= htmlspecialchars($row['email']); ?></td>
            <td><?= htmlspecialchars($row['message']); ?></td>
            <td><?= $row['submitted_at']; ?></td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="5" style="text-align:center;">No messages found.</td></tr>
      <?php endif; ?>
    </table>
  </section>

</body>
</html>

<?php $conn->close(); ?>

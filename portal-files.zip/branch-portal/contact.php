<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Handle form submission
$messageSent = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $msg = trim($_POST["message"]);

    // DB connection
    $conn = new mysqli("localhost", "root", "", "engineering_portal");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $msg);

    if ($stmt->execute()) {
        $messageSent = true;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact - Engineering Explorer</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <nav class="navbar">
    <div class="logo">📞 Contact Us</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="branches.php">📚 Branches</a></li>
      <li><a href="about.php">ℹ️ About</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <section class="hero-section">
    <div class="hero-glass">
      <h1>Send Us a Message</h1>
      <p>We value your feedback, questions, or suggestions!</p>

      <?php if ($messageSent): ?>
        <p style="color: #00ffcc; font-weight: bold;">✅ Your message has been sent successfully!</p>
      <?php endif; ?>

      <form method="POST" action="">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="email" name="email" placeholder="Your Email" required>
        <textarea name="message" placeholder="Your Message..." rows="5" required style="width: 100%; padding: 12px; border-radius: 10px; background: rgba(255,255,255,0.1); color: #fff;"></textarea>
        <button type="submit">📤 Send Message</button>
      </form>
    </div>
  </section>

</body>
</html>

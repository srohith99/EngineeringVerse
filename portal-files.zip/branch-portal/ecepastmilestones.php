<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - ECE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVIGATION -->
  <nav class="navbar">
    <div class="logo">📜 ECE History</div>
    <ul class="nav-links">
      <li><a href="ece.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- SECTION -->
  <section class="branches">
    <h2>📘 Milestones in Electronics & Communication Engineering</h2>
    <div class="branch-grid">

      <div class="branch-card civil">
        <h3>📻 Invention of Radio (1895)</h3>
        <p>Guglielmo Marconi demonstrated wireless telegraphy, enabling the very first long-distance transmission. This invention laid the groundwork for modern RF communication and all wireless technologies we use today — from FM radios to Bluetooth and Wi-Fi.</p>
      </div>

      <div class="branch-card eee">
        <h3>📺 Analog to Digital Revolution (1970s–1990s)</h3>
        <p>The transition from analog electronics to digital electronics transformed everything — televisions, computers, communication systems, and even medical devices. Digital logic, Boolean algebra, and microchips revolutionized signal clarity and computing speed.</p>
      </div>

      <div class="branch-card mech">
        <h3>🎛️ Embedded Controllers (1980s–2000s)</h3>
        <p>Microcontrollers like Intel’s 8051 and PIC series enabled real-time control in small devices. ECE graduates contributed massively to automation, robotics, smart appliances, automotive electronics, and wearable tech — all driven by embedded control systems.</p>
      </div>

      <div class="branch-card chem">
        <h3>⚙️ VLSI Evolution (Very Large Scale Integration)</h3>
        <p>From basic ICs to billion-transistor chips, VLSI allowed computers and smartphones to shrink in size while growing exponentially in power. This milestone is the foundation of semiconductor industries like Intel, AMD, and Qualcomm. It’s still one of the core domains in ECE.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🛰️ Satellite Communication & GPS (1960s–Today)</h3>
        <p>Launched initially for military communication, satellite tech evolved into GPS, satellite TV, and global Internet coverage. ECE experts in antenna design, modulation, and error correction were key in making this global tech reliable and accessible.</p>
      </div>

      <div class="branch-card csbs">
        <h3>🔌 Advent of Fiber Optic Communication (1970s–Today)</h3>
        <p>Fiber optics changed the face of high-speed data communication. Optical fibers enabled terabit transmission with minimal loss, becoming the backbone of Internet infrastructure. This directly revolutionized networking and long-distance communication systems.</p>
      </div>

    </div>
  </section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Biotechnology - Engineering Trends</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">Biotech Branch</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="bioabout.php">📚 About Biotech</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>Welcome to</span>
    <h1>Biotechnology Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>What You'll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card bio">
      <h3><a href="biocurrenttrends.php">🔥 Current Trends</a></h3>
      <p>CRISPR, Bioinformatics, Synthetic Biology, Genomics, AgriTech, Vaccines, Bioprocessing</p>
    </div>

    <div class="branch-card cseds">
      <h3><a href="biostartups.php">💡 Startup Ideas</a></h3>
      <p>Gene editing kits, Biofuel startups, Health diagnostics platforms, Plant-based protein ventures</p>
    </div>

    <div class="branch-card chem">
      <h3><a href="biofuturescope.php">📈 Future Scope</a></h3>
      <p>Bio-AI fusion, Organ regeneration, DNA computing, Precision agriculture, Personalized therapies</p>
    </div>

    <div class="branch-card mech">
      <h3><a href="biopastmilestones.php">📚 Past Milestones</a></h3>
      <p>Discovery of DNA, Human Genome Project, first insulin via genetic engineering, vaccine revolutions</p>
    </div>

  </div>
</section>

</body>
</html>

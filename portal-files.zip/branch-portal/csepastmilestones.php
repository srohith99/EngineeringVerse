<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - CSE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">CSE-Tech Milestones</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="cse.php">🔙 Back</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- WELCOME -->
  <section class="hero-section">
    <h1>Milestones in Computer Science</h1>
    <div class="hero-glass">
      <span>📜 Hello, <?php echo $_SESSION['user']; ?>!</span>
      <p>Discover how Computer Science evolved decade-by-decade into the powerful field it is today.</p>
    </div>
  </section>

  <!-- MILESTONES SECTION -->
  <section class="branches">
    <h2>Major Breakthroughs in Computing History</h2>
    <div class="branch-grid">

      <!-- 1940s -->
      <div class="branch-card cse">
        <h3>🖥️ 1940s – ENIAC & Early Computers</h3>
        <p>The Electronic Numerical Integrator and Computer (ENIAC) was the first general-purpose programmable computer.</p>
      </div>

      <!-- 1950s -->
      <div class="branch-card aidd">
        <h3>🧠 1956 – Birth of Artificial Intelligence</h3>
        <p>The Dartmouth Conference introduced the world to the concept of AI — machines that can think and learn.</p>
      </div>

      <!-- 1960s -->
      <div class="branch-card chem">
        <h3>🌐 1969 – Invention of ARPANET (Internet)</h3>
        <p>The U.S. launched ARPANET, the first network to implement TCP/IP — the base of the modern internet.</p>
      </div>

      <!-- 1970s -->
      <div class="branch-card ece">
        <h3>💾 1971 – Intel Releases First Microprocessor</h3>
        <p>Intel 4004 made it possible to embed computers in everyday devices — the beginning of microcomputing.</p>
      </div>

      <!-- 1980s -->
      <div class="branch-card bio">
        <h3>🖱️ 1983 – Birth of Graphical User Interface (GUI)</h3>
        <p>Apple Lisa and later Macintosh brought mouse-driven interfaces — making computers usable by everyone.</p>
      </div>

      <div class="branch-card eee">
        <h3>🏠 1985 – Microsoft Windows Released</h3>
        <p>Microsoft launched Windows 1.0, setting the stage for mainstream PC adoption across the globe.</p>
      </div>

      <!-- 1990s -->
      <div class="branch-card cseds">
        <h3>🐍 1991 – Python Programming Language</h3>
        <p>Created by Guido van Rossum, Python became the most beginner-friendly and AI-friendly programming language.</p>
      </div>

      <div class="branch-card cseiot">
        <h3>🌍 1991 – World Wide Web Goes Public</h3>
        <p>Tim Berners-Lee launched the web — introducing websites, hyperlinks, and HTML to the public.</p>
      </div>

      <!-- 2000s -->
      <div class="branch-card csbs">
        <h3>📦 2006 – Cloud Computing Begins (AWS)</h3>
        <p>Amazon launched AWS, making it possible for startups and companies to scale apps without owning servers.</p>
      </div>

      <div class="branch-card aidd">
        <h3>📱 2007 – Rise of Smartphones</h3>
        <p>The iPhone launch reshaped the tech industry, leading to mobile-first apps and global connectivity.</p>
      </div>

      <!-- 2010s -->
      <div class="branch-card aiml">
        <h3>📊 2012 – Deep Learning Breakthrough (AlexNet)</h3>
        <p>AI systems like AlexNet began beating humans at image recognition, revolutionizing machine vision.</p>
      </div>

      <!-- 2020s -->
      <div class="branch-card cse">
        <h3>🌐 2023 – Rise of Generative AI (ChatGPT)</h3>
        <p>Tools like ChatGPT and DALL·E started a new wave of creativity and automation using language and images.</p>
      </div>

    </div>
  </section>

</body>
</html>

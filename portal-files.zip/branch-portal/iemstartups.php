<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Startups - IEM</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">💡 IEM Startups</div>
  <ul class="nav-links">
    <li><a href="iem.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>💼 From Ideas to Industry</span>
    <h1>Startup Ideas in IEM</h1>
  </div>
</section>

<section class="branches">
  <h2>Real-World Possibilities</h2>
  <div class="branch-grid">

    <div class="branch-card csbs">
      <h3>📊 SME ERP Solutions</h3>
      <p>Build simplified ERP platforms for small manufacturers focused on local industries like garments, packaging, and tooling.</p>
    </div>

    <div class="branch-card chem">
      <h3>📦 Inventory Management as a Service</h3>
      <p>Offer automated inventory tools for retailers and logistics firms using barcodes, RFID, and real-time dashboards.</p>
    </div>

    <div class="branch-card mech">
      <h3>🛠️ Lean Consulting for Startups</h3>
      <p>Train and guide growing businesses on implementing Six Sigma, Kaizen, and process standardization affordably.</p>
    </div>

    <div class="branch-card bio">
      <h3>🧮 Production Simulation Software</h3>
      <p>Create apps that simulate factory layouts, workforce scheduling, and load balancing using drag-and-drop tools.</p>
    </div>

  </div>
</section>

</body>
</html>

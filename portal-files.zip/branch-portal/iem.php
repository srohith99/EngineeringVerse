<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>IEM - Industrial Engineering & Management</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">🏭 IEM Branch</div>
  <ul class="nav-links">
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="iemabout.php">📘 About</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>👋 Welcome, <?php echo $_SESSION['user']; ?>!</span>
    <h1>Industrial Engineering & Management</h1>
  </div>
</section>

<!-- CONTENT SECTION -->
<section class="branches">
  <h2>What You'll Explore</h2>
  <div class="branch-grid">

    <div class="branch-card iem">
      <h3><a href="iemcurrenttrends.php">⚙️ Current Trends</a></h3>
      <p>Smart Manufacturing, Lean Systems, Data-Driven Decision Making, Industry 4.0</p>
    </div>

    <div class="branch-card aiml">
      <h3><a href="iemstartups.php">💡 Startup Ideas</a></h3>
      <p>ERP for SMEs, AI-based supply chain, consulting tools, manufacturing analytics</p>
    </div>

    <div class="branch-card cseds">
      <h3><a href="iemfuturescope.php">📈 Future Scope</a></h3>
      <p>Digital twins, cyber-physical systems, AI-powered operations, virtual factory planning</p>
    </div>

    <div class="branch-card chem">
      <h3><a href="iempastmilestones.php">📚 Past Milestones</a></h3>
      <p>Taylorism, Six Sigma, Toyota Production System, JIT manufacturing, ERP evolution</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Current Trends - ISE</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">ISE Trends</div>
  <ul class="nav-links">
    <li><a href="ise.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>What's Hot in 2025?</span>
    <h1>Current Trends in Information Science</h1>
  </div>
</section>

<section class="branches">
  <h2>Top Technologies Driving ISE</h2>
  <div class="branch-grid">

    <div class="branch-card cse">
      <h3>☁️ Cloud Infrastructure</h3>
      <p>Cloud-native architectures and containerization (e.g., Kubernetes, Docker) are central to modern system design.</p>
    </div>

    <div class="branch-card ise">
      <h3>📊 Data Lakes & Analytics</h3>
      <p>Businesses are investing in advanced analytics pipelines with real-time streaming and AI insights.</p>
    </div>

    <div class="branch-card aidd">
      <h3>🧠 Natural Language Processing (NLP)</h3>
      <p>Chatbots, voice assistants, and search optimization using large language models are reshaping interfaces.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🔍 Semantic Web & Knowledge Graphs</h3>
      <p>Linked data structures allow machines to better understand, reason, and connect information.</p>
    </div>

    <div class="branch-card mech">
      <h3>🛡️ Privacy Engineering</h3>
      <p>Trends like Differential Privacy, Federated Learning, and secure data pipelines are becoming essential.</p>
    </div>

    <div class="branch-card chem">
      <h3>📲 Edge Computing</h3>
      <p>Data processing at the edge for IoT systems and smart applications is a rapidly growing area.</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About - CSE (IoT, Cyber & Blockchain)</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">About CSE-IoT-Cyber-Blockchain</div>
  <ul class="nav-links">
    <li><a href="cseiot.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>Know Your Domain</span>
    <h1>IoT | Cyber Security | Blockchain</h1>
    <p>This specialization offers a powerful combination of embedded systems, networking, cryptography, and distributed technologies.</p>
  </div>
</section>

<!-- ABOUT CONTENT -->
<section class="branches">
  <h2>Program Highlights</h2>
  <div class="branch-grid">

    <div class="branch-card cseiot">
      <h3>📡 Internet of Things (IoT)</h3>
      <p>Learn to design, program, and manage smart devices and embedded networks with real-time data streaming and edge processing using ESP32, Arduino, and sensors.</p>
    </div>

    <div class="branch-card cseds">
      <h3>🔐 Cyber Security</h3>
      <p>Explore ethical hacking, digital forensics, intrusion detection, network security layers, and risk analysis. Learn tools like Kali Linux, Wireshark, Nmap, Burp Suite, and Metasploit.</p>
    </div>

    <div class="branch-card aidd">
      <h3>💠 Blockchain Technologies</h3>
      <p>Understand consensus algorithms, smart contracts (Solidity), Ethereum architecture, NFTs, DApps, Hyperledger, and cryptographic hash functions.</p>
    </div>

    <div class="branch-card bio">
      <h3>🎓 Tools & Languages Covered</h3>
      <p>Python, Node.js, Solidity, MQTT, C++, Arduino IDE, Flask, Ethereum Remix, Wireshark, MetaMask, Firebase, Raspberry Pi.</p>
    </div>

  </div>
</section>

<!-- EXTRAS -->
<section class="branches">
  <h2>Career Roles You Can Aim For</h2>
  <div class="branch-grid">

    <div class="branch-card aiml">
      <h3>🔍 IoT Architect</h3>
      <p>Design and deploy end-to-end smart systems using sensors, cloud, and microcontrollers.</p>
    </div>

    <div class="branch-card eee">
      <h3>🛡️ Cyber Security Analyst</h3>
      <p>Protect systems, detect intrusions, and conduct real-time security audits for organizations.</p>
    </div>

    <div class="branch-card chem">
      <h3>🧠 Blockchain Developer</h3>
      <p>Create decentralized applications, build tokens, and automate processes using smart contracts.</p>
    </div>

    <div class="branch-card civil">
      <h3>🌐 Network Security Engineer</h3>
      <p>Configure firewalls, detect vulnerabilities, and harden systems to prevent cyber threats.</p>
    </div>

  </div>
</section>

</body>
</html>

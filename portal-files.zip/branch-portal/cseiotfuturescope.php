<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Future Scope - CSE (IoT, Cyber & Blockchain)</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="logo">Future Scope – CSE-IoT</div>
  <ul class="nav-links">
    <li><a href="cseiot.php">🔙 Back</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero-section">
  <div class="hero-glass">
    <span>Look Ahead</span>
    <h1>Future Scope in IoT, Cyber Security & Blockchain</h1>
    <p>Innovations of the next decade are being shaped in this field — will you be part of them?</p>
  </div>
</section>

<!-- SCOPE GRID -->
<section class="branches">
  <h2>What's Coming Next?</h2>
  <div class="branch-grid">

    <div class="branch-card cseds">
      <h3>🔐 Quantum-Resilient Cryptography</h3>
      <p>As quantum computing rises, traditional encryption will break. Next-gen cryptosystems are being designed now.</p>
    </div>

    <div class="branch-card cseiot">
      <h3>🌍 Smart Nations & Secure Infrastructure</h3>
      <p>IoT-based urban control systems integrated with AI & Blockchain for transparency and automation.</p>
    </div>

    <div class="branch-card ece">
      <h3>🔗 Blockchain + AI Integration</h3>
      <p>Trustable AI models with on-chain audits, decentralized training, and secure model ownership.</p>
    </div>

    <div class="branch-card aiml">
      <h3>🧠 Predictive IoT with Edge AI</h3>
      <p>Embedded devices running on-device AI for predictive health, traffic, industrial failure & energy control.</p>
    </div>

    <div class="branch-card chem">
      <h3>🧾 Blockchain in Supply Chain</h3>
      <p>Food, pharma, and textile industries will rely on blockchain for verified sourcing and tamper-proof logistics.</p>
    </div>

    <div class="branch-card eee">
      <h3>👁️‍🗨️ Cyber Threat Intelligence Analysts</h3>
      <p>Skilled cyber experts will act like digital detectives — predicting and mitigating advanced persistent threats (APT).</p>
    </div>

    <div class="branch-card civil">
      <h3>🚀 Space-grade IoT & Cyber Defense</h3>
      <p>Defense, satellites, and drones will demand IoT networks hardened with cryptographic autonomy.</p>
    </div>

  </div>
</section>

</body>
</html>

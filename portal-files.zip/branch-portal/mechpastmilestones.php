<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Past Milestones - Mechanical</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
  <div class="logo">📚 Mech History</div>
  <ul class="nav-links">
    <li><a href="mech.php">🔙 Back</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<section class="hero-section">
  <div class="hero-glass">
    <span>🕰️ Legacy of Innovation</span>
    <h1>Past Milestones in Mechanical Engineering</h1>
  </div>
</section>

<section class="branches">
  <h2>Moments That Changed Engineering</h2>
  <div class="branch-grid">

    <div class="branch-card mech">
      <h3>🛠️ Industrial Revolution (1760s)</h3>
      <p>Steam engines, machine tools, and mass production techniques laid the foundation for modern mechanical systems.</p>
    </div>

    <div class="branch-card civil">
      <h3>🌀 Thermodynamics (1850s)</h3>
      <p>The formulation of thermodynamic laws enabled design of efficient engines, turbines, and heat exchangers.</p>
    </div>

    <div class="branch-card ece">
      <h3>🔩 CNC Machines (1950s)</h3>
      <p>Computer-controlled machining brought unmatched accuracy and automation in manufacturing.</p>
    </div>

    <div class="branch-card chem">
      <h3>🚂 Internal Combustion Engines (1870s)</h3>
      <p>Empowered the birth of automobiles, airplanes, and modern mobility systems.</p>
    </div>

    <div class="branch-card bio">
      <h3>🚀 Jet Propulsion (1940s)</h3>
      <p>Jet engines revolutionized aviation and laid the groundwork for space exploration vehicles.</p>
    </div>

    <div class="branch-card cseds">
      <h3>⚙️ Robotics (1970s)</h3>
      <p>First industrial robots like Unimate were created, transforming assembly lines forever.</p>
    </div>

  </div>
</section>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Civil Engineering - Dashboard</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="logo">🏗️ Civil Engineering</div>
    <ul class="nav-links">
      <li><a href="index.php">🏠 Home</a></li>
      <li><a href="civilabout.php">📖 About</a></li>
      <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
  </nav>

  <!-- WELCOME SECTION -->
  <section class="hero-section">
    <div class="hero-glass">
      <span>👷 Welcome, <?php echo $_SESSION['user']; ?>!</span>
      <p><h1>Civil Engineering Portal</h1></p>
    </div>
  </section>

  <!-- MAIN OPTIONS -->
  <section class="branches">
    <h2>Explore Civil Engineering</h2>
    <div class="branch-grid">

      <div class="branch-card civil">
        <h3><a href="civilcurrenttrends.php">🌐 Current Trends</a></h3>
        <p>Smart cities, 3D printing, BIM, green buildings & more.</p>
      </div>

      <div class="branch-card aiml">
        <h3><a href="civilstartups.php">💡 Startup Ideas</a></h3>
        <p>Eco-materials, site automation, structural inspection drones.</p>
      </div>

      <div class="branch-card cseds">
        <h3><a href="civilfuturescope.php">📈 Future Scope</a></h3>
        <p>Sustainable cities, AI-powered design, zero-waste construction.</p>
      </div>

      <div class="branch-card aidd">
        <h3><a href="civilpastmilestones.php">📚 Past Milestones</a></h3>
        <p>From ancient bridges to Burj Khalifa — milestones that shaped civilization.</p>
      </div>

    </div>
  </section>

</body>
</html>
